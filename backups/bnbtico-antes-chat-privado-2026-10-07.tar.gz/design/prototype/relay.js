/* Demo local de WhatsApp directo: sin números ni envíos reales.
   Nombre de archivo conservado por compatibilidad con el prototipo. */
const CONTACT_TTL_DAYS=7, DAY_MS=86400000;
const relay={threads:[],selected:null,next:1042,clockOffset:0};
const relayNow=()=>Date.now()+relay.clockOffset;
const relayExpired=t=>relayNow()>=t.expiresAt;
const relayDate=ms=>new Intl.DateTimeFormat('es-CR',{dateStyle:'medium',timeStyle:'short',timeZone:'America/Costa_Rica'}).format(ms);
const relayActive=(house,client)=>relay.threads.find(t=>t.house===house&&t.client===client&&!relayExpired(t));
const relayCurrent=()=>relay.threads.find(t=>t.id===relay.selected);
const safe=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function relayCreate(house,client='Andrea Castro',existingLead=null){
  let t=relayActive(house,client);
  if(!t){
    const createdAt=relayNow();
    t={id:'B-'+relay.next++,house,client,createdAt,expiresAt:createdAt+CONTACT_TTL_DAYS*DAY_MS};
    relay.threads.push(t);
    const lead=existingLead||{n:client,h:house,when:'ahora',msg:'Intento de contacto por WhatsApp',score:null,count:0,rated:0};
    lead.threadId=t.id;
    if(!existingLead)S.leads.unshift(lead);
  }
  relay.selected=t.id;return t;
}
S.leads.slice().forEach(l=>relayCreate(l.h,l.n,l));
relay.selected=null;
const relayLeadExpired=l=>{const t=relay.threads.find(t=>t.id===l.threadId);return t&&relayExpired(t);};
function relayLeadExpiry(l){
  const t=relay.threads.find(t=>t.id===l.threadId);
  return t?(relayExpired(t)?'Solicitud expirada · expiró ':'Solicitud activa · vence ')+relayDate(t.expiresAt)+' (Costa Rica)':'';
}
function contactHistory(){
  return header('Mis contactos','profile')+'<p class="small muted">Registro de solicitudes, no de conversaciones. Los mensajes se intercambian directamente en WhatsApp.</p>'+
    relay.threads.filter(t=>t.client==='Andrea Castro').map(t=>`<div class="card stack"><b>${safe(HOUSES.find(h=>h.id===t.house).t)}</b><span class="xs muted">${t.id} · ${relayExpired(t)?'Expirada':'Activa'} · vence ${relayDate(t.expiresAt)}</span><button class="btn btn-wa" data-relay-select="${t.id}">Continuar por WhatsApp</button>${relayExpired(t)?`<button class="btn btn-ghost" data-contact="${t.house}">Nueva solicitud</button>`:''}</div>`).join('');
}
SCREENS.contacts=contactHistory;
const originalProfile=profile;
SCREENS.profile=()=>originalProfile()+(S.loggedIn?'<button class="btn btn-ghost" data-go="contacts">Mis contactos</button>':'');
const originalLeads=oLeads;
SCREENS['o-leads']=()=>originalLeads()+'<details class="card"><summary>Probar caducidad · demo</summary><p class="small">«No me interesa» no reinicia los 7 días ni bloquea futuras solicitudes. Recargar restablece la demo.</p><button class="btn btn-ghost" data-relay-week>Avanzar 7 días en la demo</button></details>';
const originalSheet=sheet;
sheet=function(){
  if(!S.sheet||!['contact','reply','direct'].includes(S.sheet.type))return originalSheet();
  const reply=S.sheet.type==='reply',r=reply?S.requests[S.sheet.i]:null;
  const options=reply?matches(r).filter(h=>h.ownerV&&MY.some(m=>m.id===h.id)):[];
  const t=S.sheet.type==='direct'?relay.threads.find(x=>x.id===S.sheet.thread):null;
  const h=reply?options[0]:HOUSES.find(x=>x.id===(t?t.house:S.sheet.id));
  if(!h||!h.ownerV)return '<div class="sheet"><div class="sheet-body"><b>No hay una casa verificada disponible.</b><button class="btn btn-ghost" data-close-btn>Cerrar</button></div></div>';
  const active=t||(!reply&&relayActive(h.id,'Andrea Castro'));
  const recipient=reply?r.client:t&&S.role==='owner'?t.client:h.owner;
  const msg=reply?`Hola ${r.client}, te propongo «${h.t}» para tu búsqueda. ¿Confirmamos fechas y precio?`:`Hola ${recipient}, te escribo por «${h.t}» (${h.id}) en bnbtico.`;
  return `<div class="sheet" data-close><div class="sheet-body stack" data-stop><div class="row between"><h3>WhatsApp directo</h3><button class="chip" data-close-btn>Cerrar</button></div>
    <p>Conversá directamente con ${safe(recipient)}, sin número intermediario de bnbtico.</p>
    ${active?`<div class="note">${relayExpired(active)?'Esta solicitud expiró. Continuar el contacto no crea un aviso nuevo.':'Ya existe una solicitud para esta casa. No se creará otro aviso.'} Plazo original: ${relayDate(active.expiresAt)} (Costa Rica).</div>`:''}
    ${reply?`<div class="field"><label for="relay-house">Casa que ofrecés</label><select id="relay-house">${options.map(x=>`<option value="${x.id}">${safe(x.t)}</option>`).join('')}</select></div>`:''}
    <div class="field"><label for="relay-first">Mensaje para WhatsApp</label><textarea id="relay-first" maxlength="2000" rows="3">${safe(msg)}</textarea></div>
    <p class="xs muted">Tu número puede ser visible para la otra persona en WhatsApp. Recomendamos un número de negocio. bnbtico no lee ni almacena esta conversación.</p>
    <button class="btn btn-wa" data-relay-start="${h.id}" ${t?`data-contact-thread="${t.id}"`:''} ${reply?`data-relay-request="${S.sheet.i}"`:''}>Simular apertura de WhatsApp</button>
    <p class="xs muted">Demo sin teléfonos reales: no abre WhatsApp ni envía mensajes. En la aplicación tendrás que pulsar Enviar dentro de WhatsApp. Los 7 días limitan avisos en bnbtico, no mensajes en WhatsApp.</p></div></div>`;
};
document.addEventListener('click',event=>{
  const el=event.target.closest('[data-relay-start],[data-relay-lead],[data-relay-offer],[data-relay-select],[data-relay-dismiss],[data-relay-restore],[data-relay-week]');
  if(!el)return;
  event.stopImmediatePropagation();
  const d=el.dataset;
  if(d.relayWeek!==undefined){relay.clockOffset+=CONTACT_TTL_DAYS*DAY_MS;render();return;}
  if(d.relayDismiss!==undefined||d.relayRestore!==undefined){
    const l=S.leads[Number(d.relayDismiss??d.relayRestore)];
    if(l&&!relayLeadExpired(l)){l.dismissed=d.relayDismiss!==undefined;render();}return;
  }
  if(d.relayStart){
    if(!document.getElementById('relay-first').value.trim())return;
    const r=d.relayRequest!==undefined?S.requests[Number(d.relayRequest)]:null;
    const house=r?document.getElementById('relay-house').value:d.relayStart;
    if(!HOUSES.some(h=>h.id===house&&h.ownerV))return;
    const existing=d.contactThread?relay.threads.find(t=>t.id===d.contactThread):relayActive(house,r?r.client:'Andrea Castro');
    if(existing)relay.selected=existing.id;else relayCreate(house,r?r.client:'Andrea Castro');
    if(r)r.replied=true;
    S.sheet=null;render();toast('Demo: se abriría WhatsApp directo. No se envió ningún mensaje.');return;
  }
  if(d.relayOffer){if(!S.loggedIn){go('login');return;}S.sheet={type:'contact',id:d.relayOffer};render();return;}
  const lead=d.relayLead!==undefined?S.leads[Number(d.relayLead)]:null;
  const t=relay.threads.find(t=>t.id===(lead?lead.threadId:d.relaySelect));
  if(!t)return;
  relay.selected=t.id;S.sheet={type:'direct',thread:t.id};render();
},true);
render();
