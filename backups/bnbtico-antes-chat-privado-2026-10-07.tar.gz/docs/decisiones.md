# Registro de decisiones

Formato: fecha · decisión · motivo · alternativas descartadas.

## 2026-10-05 · Asistente guiado para verificar propiedad
La usuaria aprueba botón por casa en Mis casas: pregunta si tiene certificación, guía paso a paso con enlace al Registro y ayuda para encontrar finca, código y envío tras aviso/consentimiento. Implementado en property.js como demo: código ficticio exclusivo, progreso por casa en memoria y estado «Verificación en revisión», sin sello automático. No recoge documentos reales ni consulta el Registro; revisión admin y sellos públicos con ayuda siguen pendientes. Flujo y prueba en docs/design.md.

## 2026-10-05 · Etiquetas explicadas y guía de certificación literal
Etiquetas aprobadas: «Identidad verificada» para owners y clientes; «Propietario verificado» opcional por casa y «Copropietario verificado» cuando proceda. Cada una lleva ayuda pulsable. Copy exacto en identidad-y-seguridad.md: identidad sin mencionar Veriff y propiedad con fecha, sin añadir en ese texto breve la frase de exclusión retirada por la usuaria. El alcance de las comprobaciones no cambia. Se amplía guia-verificacion-finca.md con obtención de certificación literal, código distinto de finca/plano, validación oficial, coste en el portal y resolución de problemas. Guía y requisitos documentados; botones, formulario y revisión admin pendientes de implementar. No se compra ni se solicita información real.

## 2026-10-05 · Marca bnbtico aplicada al prototipo
Se integra el logo original elegido en este chat (rana sonriente sobre hoja y texto bnbtico), conservado sin modificaciones en `design/prototype/assets/bnbtico-original.png`. La cabecera muestra únicamente el panel inferior mediante CSS; no se regenera ni se usa la captura con Canvas. Coral de marca #FF385C, variante de acción #D92349 para contraste con blanco y tonos rosados suaves; verde reservado a WhatsApp y estados positivos, con colores naturales en fotos/mapa. Se mantienen fondos cálidos, tipografías y flujos. Tokens actualizados; nombre del repo, ruta HTML e IDs CT sin cambios. Dominio y marca legal siguen pendientes.

## 2026-10-05 · Dos verificaciones: identidad obligatoria y titularidad opcional
La usuaria elige Veriff para verificar identidad y solicita una segunda comprobación opcional por casa basada en número de finca. Sustituye la decisión previa de no comprobar titularidad, sin añadir autorización de alquiler. No solicitar el segundo sello no impide publicar si se cumplen los demás requisitos. Veriff sigue sin contrato/integración; Essential es candidato de plan. El nombre preciso del sello propuesto es «Titularidad registral comprobada», no garantía de vivienda o pago. Guía: guia-verificacion-finca.md. Acceso a datos, obligaciones legales, excepciones societarias y condiciones pendientes: privacidad-verificaciones.md. Documentación creada; pantallas y comprobaciones reales aún no implementadas.

## 2026-10-05 · Reclamaciones sin recargos y devolución directa
La usuaria aprueba gestionar reportes y pedir devoluciones al owner sin que bnbtico reciba ni devuelva el dinero. Se descarta subir la cuota por denuncias: revisión con pruebas y respuesta de ambas partes, medidas proporcionales y posibilidad de reclamar. Comprobante del owner no cierra una devolución sin confirmación del cliente. Devolver no elimina medidas. Flujo simulado y límites en reclamaciones.md; no hay sanciones, archivos ni pagos reales.

## 2026-10-02 · Identidad para ambos roles; sin comprobar autorización de alquiler
La identidad es el principal servicio diferencial. Clientes y propietarios deben verificar documento, rostro y presencia real antes de contactar/enviar solicitudes o publicar/responder. El alta, exploración y preparación de borradores deben ser sencillos. La usuaria descarta verificar titularidad o autorización: queda un único sello «Identidad verificada», sin garantía sobre la casa. Esto sustituye la revisión manual solo de owners y la propuesta intermedia de dos sellos. Ver identidad-y-seguridad.md.

## 2026-10-02 · Veriff como candidato y protección de cuentas propuesta
Essential es una opción de piloto, no contratación ni elección definitiva. Plus/Premium y Sumsub se compararon; no asumir que el plan superior es imprescindible. Validar documentos locales, resultados, facturación, revisión y tratamiento/borrado de datos. Passkeys, autenticación reforzada, avisos, límites y recuperación segura se propusieron, pero requieren aprobación y diseño. No están implementados.

## 2026-10-02 · Costes y alcance de la sesión
Contabilizar identidad de clientes y propietarios. Se acepta evaluar un precio mayor por calidad, sin cambiar todavía la referencia ₡9.900/mes y primer mes gratuito. Comunidad sin anuncio como posible plan más barato, sin precio/funciones cerrados; no regalar acceso solo por verificación ni un año gratuito a verificados. Dirección de marca bnbtico, rana sobre hoja roja. Resumen consolidado: resumen-sesion-2026-10-02.md. Las entradas anteriores que siguen son históricas cuando contradicen estas decisiones.

## 2026-10-02 · Decisión final de contacto: WhatsApp directo
Se elimina el número intermediario, el chat privado simulado y la aceptación bilateral para simplificar. Cliente y owner conversan directamente en WhatsApp; bnbtico no puede garantizar que sus números queden ocultos. Se mantiene una solicitud por cliente/casa cada 7 días y «No me interesa» sin reiniciar ese plazo. La limitación afecta solo a avisos dentro de bnbtico. En Pedir casa se requiere consentimiento explícito para responder al cliente por WhatsApp. Especificación vigente: contacto-whatsapp.md. Las decisiones de intermediación que siguen son históricas.

## 2026-10-02 · Una solicitud por cliente y casa durante 7 días
Plazo desde el envío original, configurable. Los intentos repetidos abren la consulta existente sin duplicar avisos. «No me interesa» no cambia la fecha ni bloquea futuras consultas. Al vencer, el aviso deja de estar pendiente y se puede crear otra solicitud; se conservan historial y conversaciones anteriores. Se descarta el límite por propietario porque un cliente puede interesarse por varias casas. Implementado únicamente en el prototipo; especificación en `contacto-privado.md`.

## 2026-10-02 · WhatsApp intermediado y contacto con consentimiento bilateral
El cliente y el propietario hablan mediante el número de bnbtico hasta que ambos acepten compartir sus contactos. Sin contacto propietario → propietario ni reparto automático de teléfonos en solicitudes. Sustituye las decisiones anteriores de WhatsApp directo y exposición del número por consentimiento unilateral. Prototipo funcional de texto en `design/prototype/relay.js`; especificación y limitaciones en `contacto-privado.md`. Integración real, proveedor y migraciones pendientes.

## 2026-10-02 · Prioridad de comunidad local de propietarios e iteración del prototipo
La usuaria quiere que el proyecto sirva sobre todo para que los propietarios hagan comunidad local. Esta orientación complementa el catálogo y el contacto directo con clientes; no define todavía funciones concretas entre propietarios ni cambia las reglas existentes sobre WhatsApp, reservas o pagos. Próximo trabajo: continuar iterando sobre el prototipo actual. El nombre sigue abierto; se han explorado Nidaluma, Ticosticos y Localtico, sin selección definitiva ni disponibilidad de dominio garantizada.

## 2026-10-02 · Modelo de negocio: suscripción por casa, sin comisiones
Los owners pagan una cuota mensual por cada casa activa (ref. ₡9.900). Sin comisión por reserva. Motivo: replicar el modelo local (todo se cierra por WhatsApp) y diferenciarse de Airbnb/Booking. Descartado: plan único por owner (penaliza a quien tiene una sola casa) y planes por nivel (quedan para v2).

## 2026-10-02 · Sin reseñas de casas; los owners valoran a los clientes
No se puede comprobar quién se hospedó porque la reserva ocurre fuera de la app, así que las reseñas de casas serían falsificables. En cambio, los owners (que pagan) valoran a los clientes que los contactaron. La confianza hacia la casa viene de la verificación manual del owner con cédula.

## 2026-10-02 · Contactar requiere cuenta de cliente
Teléfono verificado por OTP. Permite registrar leads, que los owners sepan quién escribe y que puedan valorarlo. Descartado: contacto anónimo.

## 2026-10-02 · Precio orientativo + calendario manual
El owner fija precio base y puede marcar días ocupados/precios especiales a mano. Todo se negocia por WhatsApp. Descartado: reservas y pagos en la app.

## 2026-10-02 · Pagos de suscripción gestionados por la plataforma
Tarjeta con renovación automática + SINPE Móvil (pago manual por ciclo con recordatorio y gracia de 5 días). Checkout en web para evitar comisiones y reglas de compras in-app de Apple/Google; validar si la suscripción califica como "servicio fuera de la app". Copy: "sin permanencia", no "pausá cuando querrás".

## 2026-10-02 · Solicitudes de casa (búsqueda inversa)
El cliente describe lo que busca (estructurado + texto libre); la app notifica solo a owners cuya casa cumple. **El owner responde por WhatsApp directamente al cliente** con mensaje prellenado. Motivo: la gente ya hace todo por WhatsApp; no construir chat interno. Protección: consentimiento explícito del cliente, máx. 10 owners por solicitud, solo owners verificados reciben el número, el cliente puede cerrar la solicitud. Descartado: respuestas del owner dentro de la app (añadía un paso ajeno al hábito actual).

## 2026-10-02 · Presupuestos en total, no por noche
En solicitudes vacacionales el cliente indica presupuesto total para la estadía y el owner responde con precio cerrado por las noches pedidas. En largo plazo, por mes. El catálogo sigue mostrando "desde ₡X / noche" porque ahí no hay fechas.

## 2026-10-02 · Web y móvil desde el día 1
Monorepo con `packages/ui` y `api-client` compartidos para no duplicar. Descartado: solo web responsive primero (el owner publica desde el teléfono y el cliente busca desde el teléfono; la app nativa importa para notificaciones y presencia en tiendas).

## 2026-10-02 · Vacacional y largo plazo desde v1
Dos modos con filtros, unidad de precio y copy propios. Descartado: empezar solo con vacacional.

## 2026-10-02 · Búsqueda: mapa + lista + destinos + filtros
Se pidió "todos". En escritorio el mapa va sticky al lado de la lista; en móvil la lista manda y el mapa es un bloque arriba.

## 2026-10-02 · Filtros funcionales en v1
Personas, habitaciones, precio y amenidades (incluido **cargador eléctrico**, pedido explícitamente). Las amenidades son un enum compartido entre filtros, ficha, wizard y solicitudes, porque el matching depende de ellas.

## 2026-10-02 · Detección de requisitos en texto libre
Reglas por palabras clave en v1 (barato, predecible, sin latencia); el cliente confirma los chips. LLM en v2 si el texto libre resulta ser el camino principal.

## 2026-10-02 · Español con voseo; moneda la elige el owner
UI solo en español en v1 (inglés v2). Cada casa en ₡ o $ según el owner; la plataforma no convierte ni cobra entre partes.

## 2026-10-02 · Nombre provisional "CasaTica"
Gusta junto con "Pura Casa". Se usa como provisional en código y prototipo; se cambia fácil (un token de marca). Pendiente dominio, redes y Registro Nacional.

## 2026-10-02 · Dirección aproximada
La ficha muestra una zona (~500 m), nunca la dirección exacta; la comparte el owner por WhatsApp.

## 2026-10-02 · Dirección visual
Cálida y local (verde selva, dorado "sol", papel cálido) con la claridad de un marketplace. Verde WhatsApp reservado al botón de contacto. Tipografía: Bricolage Grotesque (display) + Nunito Sans (texto). Español con voseo.
