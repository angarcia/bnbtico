# Arquitectura

> Decisión vigente 2026-10-02: WhatsApp directo mediante enlace, sin Business Platform intermediada ni chat interno. Ver `contacto-whatsapp.md`: permisos de acceso al contacto, deduplicación y caducidad deben imponerse en servidor. Las migraciones siguen pendientes de adaptación.

## Stack
- **Monorepo** pnpm + Turborepo.
  - `apps/web`: Next.js (App Router, TypeScript). Fichas públicas con SSR para SEO; landing; checkout de suscripción.
  - `apps/mobile`: Expo / React Native (expo-router). Mismas pantallas que web salvo checkout (enlace a web).
  - `packages/ui`: componentes y tokens compartidos (Tamagui o NativeWind, por decidir). Tokens generados desde `design/tokens/tokens.json`.
  - `packages/api-client`: tipos generados de la BD + funciones de acceso.
  - `packages/config`: eslint, tsconfig, prettier.
- **Backend:** Supabase. Postgres con RLS, autenticación pendiente de validar (passkeys propuestas; OTP no basta como identidad), Storage de fotos; preferir captura de documentos/biometría en el proveedor sin duplicarlos innecesariamente, Edge Functions o pg_cron para jobs.
- **Mapa:** MapLibre + proveedor de tiles (web); react-native-maps (móvil). Ubicación con jitter/radio ~500 m.
- **WhatsApp:** deep links `https://wa.me/<E164>?text=<urlencoded>`. Sin API de WhatsApp en v1.
- **Pagos de suscripción:** pasarela local (Tilopay / ONVO Pay / Greenpay) con tarjeta recurrente y SINPE Móvil; webhooks → `subscriptions.status`.
- **Notificaciones:** push (Expo) + WhatsApp/SMS transaccional para "casa aprobada", "nuevo contacto", "nueva solicitud que coincide" y "un owner te escribió".

## Roles y auth
Ver identidad-y-seguridad.md: identidad separada de autenticación, teléfono y titularidad registral opcional por casa. Veriff elegido como dirección de producto y Essential candidato de plan; contratación, integración y cambios de esquema pendientes. Mapa propuesto de datos y requisitos jurídicos: privacidad-verificaciones.md. Passkeys y recuperación reforzada son propuestas, no capacidades confirmadas del stack. Las notificaciones transaccionales por WhatsApp descritas aquí requieren una integración separada pendiente; no confundir con el contacto directo por wa.me.

| Rol | Auth | Acceso |
|---|---|---|
| Visitante | ninguna | catálogo y fichas (sin número del owner) |
| Cliente | Cuenta; identidad aprobada antes de contactar/enviar solicitud | explorar/favoritos sin verificación de identidad; contacto condicionado |
| Owner | Cuenta; identidad aprobada antes de publicar/responder | borradores sin verificación inicial; titularidad por finca opcional, no requisito para publicar |
| Admin | cuenta interna | cola de verificación, casas, owners, reportes |

## Modelo de datos
Esquema inicial en `supabase/migrations/0001_init.sql`, pendiente de adaptar a identidad para ambos roles. No representa todavía los requisitos nuevos de `identidad-y-seguridad.md`. Entidades iniciales:

- `profiles` (rol, teléfono verificado) · `owner_profiles` (cédula, documentos, estado de verificación, WhatsApp de negocio) · `client_scores` (media, conteo, etiquetas).
- `listings` (public_id `CT-####`, modo vac/largo, tipo, ubicación aproximada, capacidad, amenidades enum[], fotos, moneda, precio base por noche o mes, mínimo de noches, estado draft/review/active/paused/rejected) · `availability` (día, ocupado, precio especial, etiqueta).
- `leads` (casa, cliente, owner, origen listing/request, fechas, personas) · `ratings` (owner → cliente, 1–5 + etiquetas).
- `requests` (modo, personas, fechas, zona, imprescindibles, presupuesto total o mensual, texto, consentimiento, máx. owners, caducidad) · `request_matches` (estado new/dismissed/replied, precio ofrecido).
- `subscriptions` (por casa, estado trial/active/paused/past_due/canceled, proveedor, renovación).
- `reports` · `admin_actions`.

Amenidades (enum): `pool, pets, ev_charger, ac, wifi, beachfront, bbq, parking, furnished, garage, accessible, no_deposit`.

## Reglas de negocio a implementar en backend
1. **Contactar requiere cuenta e identidad aprobada**, también para el owner receptor. El servidor crea o reutiliza un lead por cliente/casa durante 7 días y devuelve el enlace de WhatsApp. Solo registra intento de contacto, no envío/entrega. «No me interesa» no reinicia el plazo; ver `contacto-whatsapp.md`.
2. **El número del owner nunca sale en la API pública**; solo en la respuesta del endpoint de contacto autenticado.
3. **Valoraciones:** un owner solo puede valorar a un cliente con el que exista `lead`; una valoración por lead. `client_scores` se recalcula por trigger.
4. **Publicación:** moderación del anuncio más identidad aprobada de la persona mediante proveedor. Separar estados de anuncio, identidad y titularidad registral opcional por casa; esta última no condiciona la publicación por defecto. No comprobar autorización de alquiler. Responder a clientes también exige identidad aprobada. El esquema de la comprobación por finca aún debe diseñarse; no emitir sellos por datos aportados solo por el navegador.
5. **Matching de solicitudes:** función `match_listings_for_request()` (modo, capacidad ≥ personas, `amenities @> must_have`, zona). Job al crear la solicitud y diario para solicitudes abiertas vs. casas nuevas. Notifica como máximo `max_owners` (10) y máximo 10 solicitudes/día por owner.
6. **Número del cliente:** se expone al owner solo mediante vista/función que compruebe `request_matches` + `consent_whatsapp` + owner aprobado. Al cerrar la solicitud, los owners que no respondieron dejan de verlo.
7. **Suscripción:** `listings.status = active` requiere `subscriptions.status in (trial, active)`. Webhooks de la pasarela actualizan estado; `past_due` tiene 5 días de gracia y luego `paused`.
8. **Pedir casa:** requiere identidad aprobada. Su plazo inicial de 14 días (vacacional) / 30 (largo), máx. 3 abiertas, corresponde a búsquedas, no a avisos de contacto: estos caducan a los 7 días por cliente/casa.
9. **Extracción de requisitos del texto libre:** reglas por palabras clave en v1 (piscina, cargador/eléctrico, perro/gato/mascota, aire, wifi, playa, cochera, amueblad, "somos N"); el cliente confirma los chips antes de enviar.

## Ciclos de vida

### Casa (`listings.status`)
`draft` → (owner envía) `review` → (admin aprueba y owner verificado) `active` ↔ `paused` (owner pausa, o suscripción `past_due` vence la gracia) · `review` → `rejected` (con motivo; el owner puede corregir y reenviar).

### Suscripción (`subscriptions.status`)
`trial` (primer mes gratis, empieza al aprobarse la casa) → `active` → `past_due` (cobro fallido o SINPE no recibido; recordatorio 3 días antes, 5 días de gracia) → `paused` (casa oculta, sin cobro) → `active` al pagar · `canceled` por el owner en cualquier momento (sin permanencia; efecto al final del ciclo pagado).

### Solicitud (`requests.status`)
`open` al crearse (caduca a 14 días vac / 30 largo) → `closed` por el cliente o `expired` por job. Al cerrar, los `request_matches` en `new` dejan de poder ver el número del cliente.

## Notificaciones
| Evento | Destinatario | Canal |
|---|---|---|
| Código OTP | cliente / owner | WhatsApp (SMS fallback) |
| Casa aprobada / rechazada / más info | owner | WhatsApp + push |
| Nuevo contacto (lead) | owner | push + WhatsApp (resumen diario opcional) |
| Nueva solicitud que coincide | owner | push + WhatsApp |
| Un owner te escribió (match → replied) | cliente | push |
| Recordatorio de pago SINPE (D-3) / cobro fallido | owner | WhatsApp |
| Recordatorio "valorá a tus clientes" | owner | push semanal |

## Mensajes prellenados de WhatsApp (no plantillas de API)
Ver `docs/design.md › Flujos detallados`. Se generan en backend (para registrar el lead/match antes de devolver la URL) y el cliente puede editarlas antes de abrir `wa.me`. Codificar con `encodeURIComponent`; el emoji final es opcional.

## Extracción de requisitos del texto libre (v1)
Reglas por palabras clave, en minúsculas y sin tildes: `piscina→pool`, `cargador|electrico→ev_charger`, `perro|gato|mascota→pets`, `aire|a/c→ac`, `wifi→wifi`, `playa|frente al mar→beachfront`, `cochera|garaje→garage`, `amueblad→furnished`, `accesible|silla de ruedas→accessible`; `somos (\d+)` → personas. Nunca sobreescribe lo que el cliente desmarcó a mano. Candidato a LLM en v2.

## SEO web
Fichas indexables con SSR, sitemap por provincia y destino, Open Graph con foto de portada, URLs `/c/CT-1042-villa-brisa-tamarindo`.

## Entornos
Supabase local (CLI) para desarrollo; proyecto `staging` y `prod`. Secretos solo en variables de entorno; nunca en el repo.

## Testing
Vitest para matching, formateo de dinero y extracción de requisitos. Playwright para "buscar → ficha → contactar" y el wizard de publicación. Revisión manual del prototipo como referencia de aceptación visual.
