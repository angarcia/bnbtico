# Contacto por WhatsApp directo · vigente 2026-10-02

Sustituye a contacto-privado.md por decisión de la usuaria: simplificar el contacto sin número intermediario de bnbtico.

## Flujo y privacidad

- Cliente con sesión e identidad aprobada → anuncio de una persona con identidad aprobada → Contactar → aviso de privacidad y mensaje editable → abrir WhatsApp directo con el owner.
- En producción, abrir un enlace con mensaje prellenado no envía nada automáticamente ni demuestra que el usuario haya enviado el mensaje. Registrar intento de contacto, no entrega ni conversación.
- No hay chat interno, reenvío de mensajes, doble aceptación, plantillas ni ventana de atención de 24 horas en este flujo.
- No mostrar el teléfono en la ficha pública. Autorizar su acceso en servidor al contactar; el enlace directo utiliza el teléfono, por lo que esto no garantiza que sea secreto.
- No prometer que WhatsApp o sus ajustes oculten el número. Advertir que puede ser visible y recomendar WhatsApp Business o un número distinto del personal.
- Sin contacto propietario → propietario.
- Identidad obligatoria de ambos roles antes de contactar/publicar/responder; no se comprueba derecho a alquilar. Ver `identidad-y-seguridad.md`. La demo de autenticación todavía no aplica esta política.
- Pedir casa: consentimiento explícito para compartir contacto con hasta 10 owners verificados compatibles y recibir respuestas por WhatsApp. No repartir contactos a otros usuarios.
- No se pueden impedir la extracción o el contacto posterior una vez revelado el teléfono; quedan pendientes controles de abuso y límites de acceso del backend.

## Solicitudes y caducidad

- Una solicitud activa por cliente y casa durante 7 × 24 horas desde su creación; duración configurable.
- Volver a contactar durante ese plazo permite continuar por WhatsApp, sin crear otro aviso ni modificar la fecha original.
- «No me interesa» marca esa solicitud para el owner; no envía un mensaje al cliente, no reinicia el plazo ni lo bloquea permanentemente.
- Al vencer deja de estar pendiente. Se conserva el registro y puede iniciarse una solicitud nueva, incluso meses después.
- Abrir un contacto del historial no genera otro aviso; «Nueva solicitud» sí puede hacerlo tras la caducidad.
- Otra casa del mismo owner tiene su propio plazo.
- Estas reglas solo controlan avisos de bnbtico: no bloquean ni limitan los mensajes dentro de WhatsApp.
- bnbtico conserva el registro de solicitud, no el historial de mensajes de WhatsApp.

## Prototipo y futura implementación

- HTML existente y relay.js (nombre conservado por compatibilidad). Todo en memoria.
- Botón «Simular apertura de WhatsApp»: no utiliza números reales, no abre aplicaciones externas ni envía mensajes.
- Contactos permite responder, descartar, reactivar y avanzar 7 días con un control de demostración.
- Prueba: node tests/prototype/contact-expiry.cjs.
- Producción pendiente: enlaces reales, acceso autorizado a teléfonos, consentimiento persistente para Pedir casa, reloj del servidor y deduplicación atómica por cliente/casa.
