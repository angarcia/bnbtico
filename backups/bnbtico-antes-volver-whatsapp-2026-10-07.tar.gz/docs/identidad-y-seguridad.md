# Identidad y seguridad de cuentas

Estado al 2026-10-05. Fuente vigente para identidad y titularidad. Requisitos documentados, no implementados: el prototipo aún simula autenticación y conserva pantallas antiguas de revisión manual. Guía del owner: [verificación por finca](guia-verificacion-finca.md). Revisión jurídica y mapa de datos: [privacidad de las verificaciones](privacidad-verificaciones.md).

## Decisiones aprobadas

- La verificación de identidad es el principal servicio diferencial de bnbtico. Priorizar calidad y facilidad de uso; la usuaria acepta evaluar una cuota mayor si es necesario, sin aprobar todavía un nuevo precio.
- Identidad obligatoria para propietarios y clientes: documento, comparación facial y prueba de persona real (liveness) mediante proveedor especializado. Un código por WhatsApp/SMS acredita acceso al número, no identidad.
- Registro sencillo separado de verificación: explorar sin verificar; con cuenta, guardar favoritos y preparar borradores. Verificar antes del primer contacto o de enviar «Pedir casa»; el owner debe estar verificado antes de publicar o responder.
- La identidad se verifica por persona, no por casa ni por conversación. Criterios de reverificación por seguridad pendientes; no prometer validez perpetua ni imponer comprobaciones mensuales por defecto.
- **Dos comprobaciones aprobadas:** identidad obligatoria mediante Veriff y titularidad registral opcional por casa mediante número de finca. La segunda sustituye la decisión del 2026-10-02 de no comprobar titularidad. No se verifica autorización para alquilar.
- **«Identidad verificada»** corresponde a la persona, tanto cliente como owner. **«Propietario verificado»** corresponde a la titularidad de esa casa, con fecha y finca vinculada internamente; **«Copropietario verificado»** cuando proceda. Sociedades y otros derechos requieren revisión particular; no presentar al representante como propietario personal. Sin comprobación opcional, mostrar solo identidad, sin etiqueta negativa.
- Cada etiqueta tendrá un botón de ayuda pulsable (también en móvil). Copy aprobado de identidad: **«Comprobamos la identidad de este usuario.»** Sin mencionar Veriff en esta explicación; el proveedor sí debe figurar donde corresponda en los avisos de privacidad.
- Copy aprobado de propiedad: **«Comprobamos que quien publica figura como titular de esta propiedad en el Registro Nacional. Revisado el [fecha].»** Se retira de este texto breve la frase sobre estado de la vivienda/autorización para alquilar; no cambia el alcance real del servicio ni sustituye los avisos jurídicos.
- Guía para obtener y aportar el código de una certificación literal: [guia-verificacion-finca.md](guia-verificacion-finca.md). Asistente owner implementado en la demo con código ficticio y envío a revisión solo en memoria. La validación del código y el cotejo con la identidad no están automatizados ni implementados. Conocer el código no demuestra que quien lo aporta sea titular.
- No solicitar o no obtener el segundo sello no bloquea por sí solo la publicación. Casos de fraude acreditado siguen su proceso independiente. No basta conocer una finca ni aportar una imagen documental para obtenerlo.
- Una persona con identidad verificada puede cometer fraude o anunciar una casa ajena. No prometer anuncios legítimos, ausencia de estafas ni garantía de reserva/pago.

## Veriff: proveedor elegido como dirección de producto; contratación pendiente

La usuaria elige Veriff para la identidad obligatoria el 2026-10-05. No está contratado ni integrado. Essential continúa como candidato de plan para un piloto, no conclusión de suficiencia universal. El lanzamiento depende de documentos locales, resultados, contrato y revisión jurídica, incluida la biometría obligatoria. La consulta registral opcional es un proceso separado, no una capacidad atribuida a Essential.

| Plan | Precio publicado consultado el 2026-10-02 (USD) | Alcance relevante |
|---|---|---|
| Essential | 0,80/verificación; mínimo 49/mes | Decisión automatizada, documento, extracción de campos, comparación facial y liveness; página alojada y exportación PDF |
| Plus | 1,39/verificación; mínimo 99/mes | Automatización + especialistas, grabación de sesión y herramientas adicionales Risk Insights, FaceBlock y CrossLinks |
| Premium | 1,89/verificación; mínimo 209/mes | Opciones adicionales de personalización y eliminación de sesiones por API |

Son precios de referencia, no oferta contractual: confirmar impuestos, extras, sesiones facturables, reintentos y mínimos. No sumar automáticamente el mínimo a todas las verificaciones ni confundir verificación con usuario activo mensual.

Fuentes consultadas: [planes Veriff](https://www.veriff.com/plans/self-serve), [cobertura documental](https://www.veriff.com/supported-countries). La cobertura general incluye Costa Rica; confirmar versiones concretas de cédula, DIMEX/residencia y pasaportes necesarios. La prueba gratuita anunciada ofrece Premium: pedir una evaluación bajo las condiciones de Essential.

Plus no implica necesariamente revisión humana de todos los casos. Preguntar cuándo intervienen especialistas. Essential no es solo OCR; ya incluye comprobaciones biométricas y de presencia real anunciadas con conformidad iBeta. No atribuir esa conformidad a código propio.

Alternativas comentadas, no seleccionadas: Sumsub Basic (1,35 USD/verificación, mínimo 149 USD/mes, [fuente](https://sumsub.com/pricing/)); Premium o Plus si el piloto demuestra necesidad. Ningún paquete de identidad prueba el derecho a alquilar.

### Condiciones para elegir proveedor

- Probar facilidad de captura, abandonos, reintentos y rechazos de personas legítimas con documentos y dispositivos representativos, con consentimiento.
- Evaluar controles antifraude y tratamiento de resultados inconclusos; no aprobar por defecto un caso fallido ni sustituir el proveedor por una lectura de foto con IA generalista.
- Definir soporte, revisión/reclamación y alternativa accesible para quien no pueda completar el proceso.
- Revisar contrato, ubicación/tratamiento de datos, acceso, conservación, borrado y responsabilidades con asesoramiento apropiado antes del lanzamiento.
- Presupuestar verificaciones de ambos roles, repeticiones justificadas y recuperación, no solo las altas de owners.

## Qué construye bnbtico y qué hace el proveedor

bnbtico integra la página/SDK, muestra estados y sello, aplica permisos, gestiona incidencias y registra el resultado mínimo necesario. El proveedor especializado analiza documento, rostro y liveness. No construir una supuesta certificación iBeta propia ni equiparar extracción de datos con autenticidad.

Propuesta técnica pendiente de diseño: estado de identidad separado de teléfono, rol y estado del anuncio; referencia de sesión/proveedor y fechas; decisiones recibidas y comprobadas en servidor. Nunca conceder el sello por una redirección o dato enviado por el navegador. Validar notificaciones del proveedor, vinculación con la cuenta e idempotencia.

Preferir captura alojada en el proveedor y evitar copias innecesarias de cédulas/selfies en bnbtico. Eso no significa ausencia de acceso o responsabilidad: el proveedor puede entregar datos personales y medios según configuración y contrato. Política exacta de acceso, retención y borrado pendiente; ver privacidad-verificaciones.md. No asumir que todos los planes permiten borrar mediante API.

## Protección de cuentas — propuesta discutida, pendiente de aprobar/diseñar

La identidad al alta no impide el robo posterior de una cuenta. Se propuso:

- Passkeys como acceso preferente, usando desbloqueo del dispositivo (Face ID, huella o PIN); bnbtico no recibe la biometría local de desbloqueo. Esto es distinto de la selfie enviada al proveedor de identidad.
- Autenticación reforzada al cambiar teléfono de contacto, correo o métodos de acceso.
- Avisos de nuevos accesos/cambios y opción para cerrar sesiones.
- Límites de intentos y de solicitudes de códigos.
- Códigos de recuperación y procedimiento seguro si se pierden dispositivos; posible reverificación de identidad en casos de riesgo.
- No depender solo de WhatsApp/SMS para proteger o recuperar la cuenta. Conocer nombre y cédula no basta para recuperarla.

No se ha seleccionado proveedor de autenticación ni validado soporte de passkeys en el stack propuesto. No presentar estas medidas como disponibles en el prototipo.

## Pendientes de implementación

- Actualizar pantallas de alta, cliente, owner y admin: separar registro, teléfono e identidad.
- Sustituir etiquetas genéricas por identidad y, cuando proceda, titularidad registral opcional con alcance preciso; nunca autorización de alquiler.
- Diseñar la revisión por finca y su formulario privado, consentimiento/aviso, prueba de correspondencia con el anuncio, excepciones y vigencia. La guía ya está documentada, no implementada.
- Aplicar permisos en backend para contactar, publicar y responder, además de ocultar/deshabilitar controles en UI.
- Diseñar estados, reintentos, reclamación, recuperación y reverificación; probar también accesos no autorizados.
- Adaptar esquema/migraciones y documentación técnica detallada cuando se elijan proveedores.
