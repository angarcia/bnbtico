# Roadmap

## Decisión provisional de contacto · 2026-10-07

- [ ] Validar proveedor, aprobación del uso, límites y coste de un número intermediario por cliente: cliente en bnbtico, owner en su WhatsApp Business habitual. Ver `chat-privado.md` para enrutamiento, ventanas y ciclo de vida pendientes.
- [ ] Diseñar y simular ese puente antes de contratarlo. La demo actual todavía usa chat interno para ambos participantes y WhatsApp directo opcional con aceptación bilateral. No confundirla con una integración real.

## Hecho (sesión 2026-10-02, Cowork)
- [x] Cuestionario de requisitos y alcance v1 (ver `vision.md`)
- [x] Prototipo navegable con 21 pantallas (cliente, owner, admin, landing; móvil y web), publicado como artifact y guardado en `design/prototype/`
- [x] Sistema de diseño y tokens
- [x] Modelo de datos y migración inicial con función de matching
- [x] Decisiones: pago por casa, sin reseñas, owners valoran clientes, chat privado y WhatsApp opcional con aceptación bilateral, presupuestos en total, copy "sin permanencia"
- [x] Investigación rápida de nombre (sin conflictos evidentes; falta dominio y marca)

## v1 — lanzamiento

### Base
- [ ] Scaffold monorepo (pnpm, Turborepo, Next.js, Expo, packages/ui con tokens)
- [ ] Supabase: migración inicial, seed, RLS, Storage (público/privado)
- [ ] Elegir autenticación y roles; evaluar passkeys y recuperación segura (propuesta). OTP no sustituye identidad.
- [ ] Piloto Veriff Essential: documentos locales, facilidad, rechazos, casos dudosos, costes y borrado; Veriff elegido como dirección de producto, plan/contrato pendientes.
- [ ] Integrar identidad para clientes y propietarios, permisos backend y notificaciones verificadas del proveedor.
- [ ] Adaptar migraciones y probar estados, reintentos, reclamación y acceso no autorizado.

### Cliente
- [ ] Home: modo vacacional / largo plazo, buscador, chips de provincia, lista de tarjetas
- [ ] Mapa con pins de precio (web sticky; móvil toggle)
- [ ] Filtros: personas, habitaciones, precio, amenidades (incl. cargador eléctrico), solo verificados
- [ ] Ficha: galería, amenidades, calendario, mapa aproximado, owner, aviso antifraude
- [ ] Contactar → login e identidad aprobada → chat privado → WhatsApp opcional tras doble aceptación (demo lista, backend pendiente; `chat-privado.md`)
- [ ] Favoritos
- [ ] Mi cuenta con puntuación como cliente
- [ ] Alertas simples de nuevas casas (provincia + modo)
- [ ] Pedir casa: formulario + detección de requisitos en texto + consentimiento + vista previa de coincidencias
- [ ] Mis solicitudes: owners que escribieron, cerrar solicitud
- [ ] Reportar anuncio

### Owner
- [ ] Registro sencillo y borrador; documento + rostro + liveness antes de publicar/responder. Sin comprobar autorización para alquilar.
- [ ] Titularidad registral opcional por finca/casa: formulario privado y guía (guia-verificacion-finca.md), cotejo con identidad, revisión particular y sello con fecha. Implementación condicionada a privacidad-verificaciones.md; no bloquea publicación por no solicitarla.
- [ ] Wizard de publicación (5 pasos) con validación de fotos (sin teléfonos/enlaces)
- [ ] Panel con vistas, contactos, casas activas, suscripción
- [ ] Calendario: ocupado, precio especial, temporada alta, mínimo de noches
- [ ] Contactos: leads, valorar cliente (estrellas + etiquetas), responder en chat privado
- [ ] Solicitudes: coincidencias, responder en chat privado con casa coincidente, descartar
- [ ] Notificaciones: casa aprobada, nuevo contacto, nueva solicitud
- [ ] Suscripción por casa: checkout web (tarjeta recurrente + SINPE Móvil), recordatorios, gracia, pausar/cancelar

### Admin
- [ ] Llevar reclamaciones.md a producción: pruebas privadas, permisos, decisiones motivadas, apelaciones y medidas efectivas. La demo claims.js solo registra medidas, sin aplicarlas.
- [ ] Cola de incidencias de identidad de ambos roles separada de moderación del anuncio y de titularidad registral opcional; no comprobar autorización para alquilar.
- [ ] Aprobar / pedir más info / rechazar con motivo
- [ ] Tabla de casas y de owners (pagos vencidos)
- [ ] Reportes de clientes

### Landing y lanzamiento
- [ ] Landing pública (hero, 3 pasos, precio, comparativa, FAQ)
- [ ] SEO: SSR de fichas, sitemap, Open Graph
- [ ] Términos, privacidad (Ley 8968), política antifraude
- [ ] Onboarding de los primeros 20–30 owners a mano (Guanacaste, Jacó, GAM)

## v2
- [ ] Planes por nivel (destacados, más fotos, estadísticas)
- [ ] Descuento por volumen
- [ ] Inglés para turistas y precios en dólares por defecto en zonas turísticas
- [ ] Total orientativo en la ficha al elegir fechas (noches × precio)
- [ ] Extracción de requisitos del texto con LLM
- [ ] Re-matching diario de solicitudes abiertas con casas nuevas
- [ ] Detección automática de fraude en fotos (búsqueda inversa, teléfonos en imagen)
- [ ] Importar calendario externo (iCal) para marcar ocupados

## Quizás nunca
- Reservas y pagos dentro de la app (rompe el modelo sin comisiones)
- Reseñas de casas (no verificables sin reserva en la app)
- Intermediación de WhatsApp con números puente (descartada para este experimento)
- Seguro o garantía de depósito

## Pendientes de decisión
- [ ] Validación jurídica de identidad/biometría obligatoria y consulta registral opcional, datos accesibles desde Veriff, proveedores/países, avisos, derechos, retención e inscripción/protocolos ante PRODHAB. Ver privacidad-verificaciones.md.
- [ ] Titularidad opcional: coste, operador registral, vigencia, renovaciones y tratamiento de sociedades/copropiedad/otros derechos.
- [x] Integrar en el prototipo el logo original de rana sobre hoja y paleta coral de bnbtico (2026-10-05).
- [ ] Validar dominio/redes/marca para bnbtico.
- [ ] Revisar cuota de referencia ₡9.900 incluyendo identidad de clientes y owners; primer mes gratuito. No hay aumento aprobado.
- [ ] Pasarela: Tilopay vs ONVO Pay vs Greenpay
- [ ] Confirmar reglas de App Store / Play sobre cobrar la suscripción fuera de compras in-app
- [ ] Librería UI compartida: Tamagui vs NativeWind
- [ ] Proveedor de OTP (Twilio, Meta Cloud API, local)
- [ ] Zonas para solicitudes: lista cerrada de destinos vs provincia/cantón vs radio
- [ ] Política de retención y acceso a cédulas/selfies
