# Diseño

> Demo implementada 2026-10-07: chat privado por defecto; WhatsApp directo opcional con doble aceptación. Decisión posterior provisional, aún no implementada: cliente en bnbtico y owner en su WhatsApp Business, con número intermediario por cliente. Ver `chat-privado.md` para el estado real y las condiciones; se conservan los 7 días.

Referencia viva: `design/prototype/casatica-prototipo.html` (abrir en el navegador; selector Cliente / Owner / Admin / Landing y Móvil / Web). También publicado como artifact privado en claude.ai (gallery → "CasaTica Prototipo"). Tokens en `design/tokens/tokens.json`.

## Cómo usar el prototipo
- Es un único HTML sin dependencias: datos de ejemplo en JS, pantallas renderizadas por función, navegación por `data-go`. Los selectores de arriba cambian rol y dispositivo; la misma pantalla se adapta con container queries (390 px en marco de teléfono, ancho completo en web).
- Lo que **sí** funciona: cambiar modo, filtros reales (provincia, personas, habitaciones, piscina, mascotas, cargador eléctrico, A/C, wifi), favoritos, abrir ficha, flujo de contacto (login → sheet → toast), pedir casa con detección de requisitos, mis solicitudes, wizard de 5 pasos, calendario (tocar días), valorar clientes, solicitudes del owner con sheet de respuesta, aprobar/rechazar en admin.
- Lo que **no**: buscador de texto, rango de precio, mapa real, subida de fotos, pagos. Son decorativos.
- Las "fotos" son degradados con etiqueta; en producción van imágenes reales 16:11 en tarjeta y 4:3 en galería.

## Flujos detallados
Reclamaciones: ver `reclamaciones.md` para entradas por rol, respuesta del owner, devolución directa con confirmación del cliente y decisiones/revisión de administración. Simulación en claims.js, sin recargos.

Requisitos vigentes, no descripción exacta de todas las pantallas actuales: identidad-y-seguridad.md prevalece sobre la demo antigua. Registro separado de identidad obligatoria; desde el 2026-10-05 se añade titularidad registral opcional por finca/casa, sin comprobar autorización de alquiler. Guía de contenido: guia-verificacion-finca.md; privacidad y revisión jurídica: privacidad-verificaciones.md. No implementado en las pantallas. Marca bnbtico/rana sobre hoja y paleta coral sí aplicadas al prototipo el 2026-10-05; tokens vigentes más abajo.


### Contactar en privado (cliente)
1. En la ficha elige llegada, salida y personas (vacacional) o "desde cuándo" (largo plazo) y toca **Contactar**.
2. Sin sesión → registro sencillo. Antes de contactar, completar identidad (documento + rostro + liveness); teléfono/OTP no basta. Volver al contacto tras aprobación, sin repetir por conversación. Pendiente de implementar en la demo.
3. Chat privado: nombre del owner, casa, mensajes y campo de texto. «Pasar a WhatsApp» es secundario y exige confirmación de ambas partes; rechazar permite seguir acá.
4. El primer mensaje crea/reutiliza una solicitud por cliente/casa durante 7 días. Reabrirla no envía otro aviso. La demo no envía mensajes reales; ver `chat-privado.md`.

Mensaje prellenado (vacacional):
> Hola {nombreOwner}, vi tu casa «{título}» en CasaTica (ref {CT-####}). ¿Está disponible del {llegada} al {salida} para {personas} personas? Gracias 🙂

Largo plazo:
> Hola {nombreOwner}, vi tu {tipo} «{título}» en CasaTica (ref {CT-####}). ¿Sigue disponible a partir de {mes}? Somos {personas} personas.

### Pedir casa (cliente) → responder (owner)
1. Cliente: elige Vacaciones / Para vivir, personas (stepper), fechas o "desde cuándo", zona, chips de imprescindibles, texto libre, presupuesto **total** (vacacional) o mensual (largo plazo).
2. Al salir del texto libre, la app detecta requisitos ("piscina", "cargador", "perro", "somos 3") y marca chips; toast "Detectamos requisitos en tu texto". El cliente puede corregir.
3. Vista previa: "N casas cumplen hoy tus requisitos · sus owners recibirán tu solicitud" con avatares.
4. Checkbox de consentimiento: "Acepto que hasta {min(10, N)} owners verificados que cumplan mis requisitos me envíen propuestas privadas en bnbtico, sin compartir mi teléfono."
5. Enviar (requiere cuenta e identidad aprobada). Toast "Enviada a N owners". → Mis solicitudes.
6. Owner: recibe notificación; en Contactos → Solicitudes ve la tarjeta (cliente + ★, modo · personas · fechas · zona, chips, badge de presupuesto, texto, "Coincide con: {casa}"). Toca **Responder**.
7. Elige una casa coincidente y escribe su propuesta en el chat. El envío marca `replied`. Alternativa: «No me interesa».
8. Cliente, en Mis solicitudes: lista de owners que escribieron (casa, verificado, precio ofrecido) con Ver casa / Chat; aviso "revisá que el chat venga de un owner de esta lista"; Cerrar solicitud.

Mensaje prellenado del owner:
> Hola {nombreCliente}, soy {owner} de CasaTica. Vi que buscan casa para {personas} personas ({fechas}) con {requisitos}. Mi casa «{título}» en {zona} cumple todo: {enlace ficha}. Les puedo dejar las {n} noches en {precio total} en total. ¿Les sirve?

### Publicar casa (owner)
Se puede preparar el borrador sin verificar identidad, pero no publicarlo ni responder hasta su aprobación. No hay trámite de autorización para alquilar. Los tiempos de revisión de la demo son ilustrativos, no SLA comprometido.

Wizard de 5 pasos con barra de progreso: **Tipo** (vacacional/largo + casa/apto/cabina/quinta) → **Ubicación** (provincia, cantón, zona, pin aproximado; aviso de radio ~500 m) → **Detalles** (personas, habitaciones, baños, chips de amenidades con nota "marcá bien las amenidades: así te llegan solicitudes", título con hint "evitá MAYÚSCULAS", descripción) → **Fotos** (mín. 5, horizontales, sin marcas de agua ni teléfonos; aviso de que se rechazan) → **Precio y WhatsApp** (precio por noche/mes, moneda ₡/$, número de WhatsApp de negocio con aviso de no usar personal, resumen "₡9.900/mes, se cobra solo al aprobarse") → **Enviar a revisión**. Toast "te avisamos en menos de 24 h"; la casa aparece como "En revisión".

### Verificar propiedad (owner) · demo implementada 2026-10-05

Desde Panel o Mis casas, cada casa activa de ejemplo incluye **Verificar propiedad**. Abre `o-verify`, conservando la casa seleccionada. Pregunta inicial: «¿Ya tenés una certificación literal?»; quien tiene código salta al envío y quien no lo tiene recorre tres pantallas: preparar referencia (con ayuda «No sé mi número de finca»), obtener certificación (enlace oficial en pestaña nueva) y emitir/copiar código. Botones Atrás, Continuar y Salir y continuar después.

El paso final muestra campo de código, aviso de privacidad de demostración y consentimiento explícito. Solo permite **Usar código de ejemplo** (`RNPDIGITAL-DEMO-2026`), sin escribir ni subir datos reales. Enviar cambia la solicitud a **Verificación en revisión**, no concede un sello ni cambia publicación, identidad o suscripción. Cada casa conserva su paso/código/consentimiento en memoria; salir y volver permite continuar, recargar lo borra. No hay solicitudes al Registro, compras, persistencia, autenticación real ni conexión con la cola admin.

Implementación: `design/prototype/property.js`, cargado tras relay.js y claims.js; pruebas: `node tests/prototype/property-verification.cjs`. Guía de contenido y fuentes: `guia-verificacion-finca.md`. Los sellos públicos con sus ayudas y la cola admin registral siguen pendientes; el asistente incorpora una explicación de «Propietario verificado», no un sello concedido.

### Identidad y moderación (admin)
Separar incidencias de identidad de clientes/owners, moderación de anuncios y revisión registral opcional por casa. Mostrar estado/fecha/referencia del proveedor y gestionar revisión, sin aprobar automáticamente casos dudosos. Datos de finca solo al solicitar la comprobación opcional, mediante formulario privado; no pedir autorización de alquiler. No prometer SLA 24 h hasta validarlo. La demo antigua de cédula/selfie sigue pendiente de sustituir. Ver `identidad-y-seguridad.md`.

Revisión solicitada el 2026-10-05: la usuaria prefiere que la cola principal de verificación admin sea únicamente para las solicitudes opcionales de titularidad en el Registro; la decisión de identidad corresponde a Veriff. El código actual de `aQueue` todavía muestra cédula/selfie, mezcla owner y casa nueva, promete SLA 24 h y al aprobar anuncia «Owner aprobado · casa publicada». Eso no representa el nuevo diseño.

Propuesta pendiente de implementar: renombrar la cola a «Titularidad de propiedades», mostrar casa/finca/derecho, referencia del titular y estado de identidad de solo lectura; permitir comprobar titularidad, pedir aclaración o dejarla no comprobada, con fecha, fuente y motivo. Ni aprobar esta cola verifica identidad ni publica automáticamente la casa; no obtener el sello opcional no pausa por sí solo el anuncio. Incidencias de Veriff se gestionan como soporte/reintento/revisión con el proveedor, sin botón para autoaprobar identidad. Moderación de anuncios y reclamaciones conservan sus flujos separados. No mostrar documentos de identidad completos por defecto.

## Dirección
Cálida y local, con la claridad de un marketplace. Marca **bnbtico**, rana sonriente sobre hoja en coral, aplicada al prototipo el 2026-10-05. Original conservado en `design/prototype/assets/bnbtico-original.png`; CSS encuadra su panel inferior sin modificar la imagen. Logo compacto en cabeceras móvil y web. Coral #FF385C para marca y coral profundo #D92349 para acciones con texto blanco; fondos cálidos y rosas suaves. Verde para WhatsApp y estados positivos; dorado escaso en estrellas/avisos. Fotos y mapa conservan sus colores naturales. Español de Costa Rica con voseo.

## Roles y navegación
- **Cliente** (móvil: tab bar inferior; web: barra superior): Explorar · Pedir casa · Favoritos · Mi cuenta.
- **Owner:** Panel · Mis casas · Calendario · Contactos (Me contactaron / Solicitudes) · Cuenta.
- **Admin:** Verificación · Casas · Owners.
- **Landing** pública para captar owners.

## Pantallas

### Cliente
- **Home:** segment Vacacional / Largo plazo, buscador, chips de provincia, mapa con pins de precio (sticky lateral en escritorio), tarjetas. Línea «N casas · precios orientativos, acordalos con el owner».
- **Filtros:** provincia, personas (mín.), habitaciones (mín.), amenidades (piscina, mascotas, ⚡ cargador eléctrico, A/C, wifi, frente al mar, rancho/BBQ, accesible; en largo plazo amueblado, cochera, sin depósito), rango de precio, "solo owners verificados" activo por defecto. Nota que enlaza a "Pedí una casa".
- **Ficha:** galería (mosaico en escritorio), badges (Identidad verificada de quien publica, modo, ref CT-####), título, zona, descripción, amenidades, calendario con ocupados y temporada alta, mapa aproximado, tarjeta del owner, aviso antifraude. Panel sticky con precio "desde", fechas, personas y botón Contactar; en móvil barra inferior fija con precio + botón.
- **Chat:** conversación privada por casa, mensajes de ambos y composer. Confirmación de WhatsApp separada con advertencia y doble aceptación.
- **Login:** alta sencilla separada de identidad. Passkeys propuestas, pendientes de validación. Documento + rostro + liveness al intentar contactar/publicar/responder, no al explorar.
- **Pedir casa:** segment Vacaciones / Para vivir, stepper de personas, fechas, zona, chips de imprescindibles, texto libre con detección de requisitos, presupuesto **total** (vacacional) o mensual (largo), vista previa "N casas cumplen hoy" con avatares, checkbox de consentimiento, botón enviar.
- **Mis solicitudes:** criterios, texto, lista de owners que escribieron (casa, verificado, precio ofrecido) con Ver casa / Chat, aviso antifraude, cerrar solicitud.
- **Favoritos** y **Mi cuenta** (puntuación como cliente con etiquetas, casas contactadas, alertas por zona, idioma).

### Owner
- **Panel:** 4 stat tiles (vistas 30 d con sparkline, contactos, casas activas, suscripción), aviso de solicitudes nuevas, aviso de clientes sin valorar, mis casas.
- **Mis casas:** tarjetas con vistas/contactos/precio, estado (Activa / En revisión), nota de pago por casa.
- **Publicar casa (wizard 5 pasos):** Tipo → Ubicación (pin aproximado) → Detalles (amenidades, título, descripción) → Fotos (mín. 5, sin teléfonos) → Precio y WhatsApp (número de negocio, resumen de suscripción) → Enviar a revisión.
- **Calendario y precios:** marcar ocupado por día, precio especial, temporada alta, mínimo de noches.
- **Contactos / Me contactaron:** leads con puntuación previa del cliente, 5 estrellas para valorar, botón Responder al chat.
- **Contactos / Solicitudes:** solicitudes que coinciden con alguna casa del owner (cliente + ★, criterios, presupuesto, texto, "coincide con: {casa}"), «Responder» (selector de casa y chat privado) o "No me interesa".
- **Cuenta** y **Suscripción** (desglose por casa, total, próximo cobro, anual, pausar).

### Admin
- **Cola de identidad:** incidencias de ambos roles y estados del proveedor; separada de moderación de casas. Sin sello ni revisión de autorización para alquilar.
- **Casas** (tabla con estado, vistas, contactos, MRR) y **Owners** (pagos vencidos, churn).

### Landing
Hero con la frase de visión, 3 pasos (Publicás · Te encuentran · Acordás los detalles), caja de precio con "sin permanencia", tabla comparativa (CasaTica / plataformas con comisión / solo WhatsApp), casas recientes, FAQ.

## Sistema de diseño

### Color
| Token | Light | Dark | Uso |
|---|---|---|---|
| bg | #F7F5EF | #141917 | fondo |
| surface / surface2 | #FFFFFF / #EFEDE6 | #1C2320 / #242D29 | tarjetas / chips |
| fg / muted | #1B2420 / #5F6B64 | #EDEFEA / #A3ADA6 | texto |
| line | #DDD9CE | #2F3934 | bordes |
| coral | #FF385C | #FF385C | marca |
| primary / primaryInk / primarySoft | #D92349 / #A81736 / #FFF0F3 | #FF8097 / #FFADC0 / #44232D | acciones, selección y fondos de marca |
| primaryOn | #FFFFFF | #35101A | texto sobre primary |
| successInk / successSoft | #124634 / #DCEFE4 | #8FD3B0 / #1E3A2D | estados positivos y verificado |
| sun / sunSoft / sunInk | #E8A33D / #FBEFD9 / #7A4E07 | #F0B24F / #3B2E17 / #F3D6A1 | estrellas, temporada alta, avisos |
| whatsapp | #25D366 (texto #063B1E) | igual | solo CTA de contacto |
| ok / warn / bad | #2E8B57 / #C97A12 / #C2432F | iguales | estados |

### Tipografía
Bricolage Grotesque 700/800 para títulos y cifras; Nunito Sans 400/600/700 para texto. Escala 11 (eyebrow uppercase) · 12 · 13 · 15 base · 17 · 20 · 22 · 24–26 · 32/50 hero. Cifras tabulares. Formato `₡95.000` / `$120`.

### Forma
Radios: tarjetas 14–16, botones 12, inputs 10, chips 999. Espaciado base 4; padding de vista 16 móvil / 32 escritorio. Una sola sombra suave. Breakpoints por contenedor: 640 (2 columnas), 800 (nav superior, ficha en 2 columnas), 1000 (3 columnas + mapa sticky).

### Componentes clave
ListingCard · Badge Identidad verificada · Botón Contactar (+ barra inferior en móvil) · Chat privado · Confirmación de WhatsApp · Chips de filtro · Segment control · Calendario (L K M J V S D, ocupado rayado, alta en sunSoft) · Stat tile con sparkline · Wizard de 5 pasos · Lead row con estrellas · Request form · Request card (owner) · Reply sheet · Note (aviso) · Admin queue card.

### Copy
Voseo tico, directo. Siempre "orientativo" junto al precio. Frases fijas: "Sin comisiones. Hablás directo con {owner}." · "CasaTica no procesa pagos." · "La dirección exacta la comparte el owner." · "Sin permanencia ni contratos".

### Accesibilidad
Contraste AA en ambos temas, focus ring visible (sun), `aria-label` en botones de icono, `prefers-reduced-motion`, áreas táctiles ≥ 40 px.
