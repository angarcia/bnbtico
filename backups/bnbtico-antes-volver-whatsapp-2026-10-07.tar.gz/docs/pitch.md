# Pitch a owners

## En una frase
Publicá tu casa una vez, que te vea todo el país, y hablá en privado con tus clientes. Pasen a WhatsApp si ambos quieren. ₡9.900 al mes por casa, cero comisiones, sin permanencia.

## El pitch (60 segundos)
Hoy alquilás tu casa a conocidos y conocidos de conocidos, por WhatsApp. Funciona, pero solo te llega quien ya te conoce. Si querés más alcance tenés que irte a Airbnb o Booking, y ahí te quedás con un 12–18 % menos en cada reserva, te fijan reglas de cancelación, retienen tu plata y el cliente deja de ser tuyo.

CasaTica es un catálogo nacional. Subís fotos, zona y un precio orientativo; verificamos la identidad de propietarios y clientes con documento, rostro y prueba de persona real; y cuando alguien se interesa, toca Contactar y te escribe en el chat privado de bnbtico. Pueden pasar a WhatsApp si ambos aceptan. Fechas, precio y pago los arreglan ustedes, como siempre. Además, cuando un cliente escribe "somos 3, queremos piscina y cargador eléctrico en Guanacaste", si tu casa cumple te avisamos y le podés escribir vos primero.

Cuesta ₡9.900 al mes por casa. Una reserva de fin de semana lo paga. Si no te sirve, pausás y dejás de pagar.

## Objeciones y respuestas

**"Ya alquilo bien por WhatsApp, ¿para qué?"**
Para que te escriban personas que no conocés, de otras provincias, en temporada baja. Podés seguir usando WhatsApp por acuerdo mutuo; lo que cambia es cuánta gente te encuentra.

**"¿Por qué pagar si en Facebook es gratis?"**
En Facebook competís con cien anuncios sin filtro ni verificación, y la mitad de los mensajes son curiosos. Aquí el cliente tiene cuenta con identidad verificada, ves su puntuación antes de contestar y los que te escriben buscan exactamente lo que ofrecés.

**"Airbnb me trae turistas extranjeros."**
Cierto, y podés seguir ahí. CasaTica es para el mercado local que hoy no te encuentra, y no cobra comisión: cada reserva que entra por aquí es 100 % tuya.

**"No quiero dar mi número a cualquiera."**
Tu número no aparece en el anuncio. No se muestra en el chat. Solo se habilita WhatsApp después de que vos y el cliente acepten compartir contacto. Te recomendamos usar un número de negocio (WhatsApp Business).

**"¿Y si me estafan o me dejan plantado?"**
Vos valorás a cada cliente después de hablar, y esa puntuación la ven los demás owners. Un cliente con mala puntuación lo sabés antes de responder.

**"¿Por qué no hay reseñas de mi casa? Tengo buenas."**
Respuesta histórica del diseño inicial de reseñas, pendiente de actualizar con el nuevo flujo por invitación. Para confianza, desde el 2026-10-05 se exige identidad y se ofrece comprobación registral opcional por casa, sin verificar autorización de alquiler. Ver `identidad-y-seguridad.md`.

**"¿Qué pasa si no me escribe nadie?"**
El primer mes es gratis. Si al mes no te sirvió, pausás y no pagás nada. Además te avisamos de solicitudes de clientes que coinciden con tu casa, así no dependés solo de que te encuentren.

**"¿Tengo que mantener un calendario?"**
No es obligatorio. Si marcás los días ocupados evitás mensajes por fechas que ya tenés tomadas, pero el precio y las fechas finales siempre se confirman con el cliente.

**"¿Cómo pago?"**
Tarjeta con renovación automática o SINPE Móvil cada mes. Sin contrato, sin permanencia.

## Para el cliente (mensaje de la landing y redes)
- "Conectá con personas cuya identidad ha sido verificada. Hablás en privado, con WhatsApp opcional por acuerdo mutuo, sin comisiones escondidas en el precio."
- "¿No encontrás lo que buscás? Contanos cuántos son, cuándo van y qué necesitan (piscina, mascotas, cargador eléctrico…) y te escriben los owners que lo tienen."
- "Nunca te pedimos pagos. Si alguien lo hace en nuestro nombre, reportalo."

## Primeros owners (plan de captación)
1. Empezar por 3 zonas con demanda local clara: Guanacaste (Tamarindo/Flamingo), Jacó/Herradura y GAM para largo plazo.
2. Onboarding a mano: visita o videollamada, fotos con el teléfono, preparación guiada del anuncio y verificación de identidad; no prometer plazos de aprobación hasta medirlos.
3. Primer mes gratis y, mientras no haya masa crítica de clientes, sembrar solicitudes reales de conocidos para que los owners vean movimiento desde la primera semana.
4. Pedir a cada owner que comparta su ficha en sus grupos de WhatsApp: trae clientes al catálogo sin coste.

## Cierre
¿Tenés las fotos en el teléfono? Te ayudamos a preparar el anuncio y verificar tu identidad antes de publicarlo. También podrás solicitar la comprobación opcional de titularidad registral con el número de finca. No verificamos autorización para alquilar ni garantizamos reservas o pagos. Guía: `guia-verificacion-finca.md`; funciones aún pendientes de implementación.
