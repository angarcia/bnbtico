# Reclamaciones y devoluciones · 2026-10-05

## Decisiones aprobadas

- La cuota no aumenta por denuncias. No hay multas ni recargos automáticos por reportes, ni reverificación de pago impuesta automáticamente al denunciado.
- Reporte no equivale a culpabilidad: revisar pruebas, escuchar a ambas partes, motivar decisiones y permitir solicitar revisión.
- Se pueden pedir explicaciones, advertir o aplicar medidas proporcionales ante incumplimientos comprobados. Una restricción temporal durante revisión requiere indicios creíbles y justificación; no basta el número de denuncias.
- bnbtico ayuda a solicitar una devolución; el owner paga directamente al cliente. La plataforma no recibe, custodia ni adelanta ese dinero ni garantiza reembolsos.
- El owner puede aceptar, proponer otra solución o rechazar explicando su posición. Presentar un comprobante no confirma recepción: debe confirmarla el cliente. El silencio no cierra automáticamente el caso.
- La devolución y la revisión de conducta son independientes: pagar no elimina medidas ni evita investigar. Sin acuerdo, orientar a canales oficiales; no entregar documentos de identidad a la contraparte.
- Veriff aporta trazabilidad de identidad, no prueba de culpabilidad ni un seguro. Reverificar tiene sentido ante dudas de suplantación/control de cuenta; un upgrade individual de Essential a Plus no está confirmado.

## Prototipo

Archivo claims.js, cargado tras relay.js. Cliente: ficha → Reportar un problema / solicitar devolución, o Mi cuenta → Reclamaciones y ayuda. Owner: Cuenta → Reclamaciones y ayuda. Admin: Reclamaciones.

El cliente selecciona casa, describe hechos y pruebas de ejemplo y, opcionalmente, indica importe/moneda. El owner responde, acepta devolver o registra referencia ficticia de comprobante. El cliente confirma recepción o indica que no recibió. Administración pide respuesta, registra resultado/medida con motivo o marca sin acuerdo. Ambas partes pueden solicitar revisión de decisiones; se conserva historial en memoria.

Solo simulación: sin archivos reales, pagos, mensajes externos ni integración con Veriff. Cambiar rol permite probar a ambas partes; no representa autorización de producción. Owners simulados limitados a Marcela (MY[0]); cliente Andrea. Las medidas son decisiones registradas de ejemplo, NO bloquean cuentas ni anuncios en esta demo. Recargar borra los casos. Los avisos de 7 días no borran reclamaciones.

## Antes de producción

- Diseñar permisos de servidor, evidencias privadas y acceso separado de notas internas; preservar versiones de anuncio/contacto y trazabilidad.
- Definir plazos de respuesta, criterios de revisión, apelaciones, suspensión/expulsión y levantamiento de medidas; no inventar SLA en la demo.
- Definir conservación por denuncia con asesoramiento legal y proveedor. Essential publica 3 meses de acceso a datos y opción de retención ampliada; confirmar contrato, disponibilidad y preservación, no asumir archivo perpetuo. Fuente consultada: https://www.veriff.com/plans/self-serve.
- Revisar condiciones legales de gestión de reclamaciones y solicitudes de autoridades en Costa Rica. No manejar dinero no elimina por sí solo todas las responsabilidades.
- Implementar restricciones efectivas, recuperación segura de cuentas y carga/validación de pruebas antes de presentar medidas como aplicadas.

Pruebas de demo: node tests/prototype/claims.cjs y node tests/prototype/contact-expiry.cjs.
