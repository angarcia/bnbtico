/* Reclamaciones: demo en memoria. Sin pagos, archivos, mensajes ni sanciones reales. */
const claims={items:[],next:1,selected:null};
const CLAIM_STATUS={review:'En revisión',owner:'Esperando respuesta del owner',resolved:'Recepción confirmada',unresolved:'Sin acuerdo'};
const CLAIM_REFUND={none:'Sin devolución acordada',accepted:'Owner acepta devolver',pending_confirmation:'Comprobante aportado · falta confirmar',disputed:'Cliente indica que no recibió el dinero',confirmed:'Recepción confirmada por el cliente'};
const CLAIM_MEASURE={none:'Sin medida',warning:'Advertencia',restriction:'Restricción temporal',suspension:'Suspensión'};
const CLAIM_FINDING={pending:'Pendiente de revisión',substantiated:'Incumplimiento comprobado',unsubstantiated:'No acreditado con las pruebas disponibles'};
const claimNote=(c,text)=>c.history.push({at:new Date().toISOString(),actor:S.role,text});
const claimAllowed=c=>S.role==='admin'||(S.role==='guest'&&S.loggedIn&&c.client==='Andrea Castro')||(S.role==='owner'&&c.owner===MY[0].owner);
function claimCreate(data){
  const h=HOUSES.find(h=>h.id===data.house),amount=Number(data.amount);
  if(S.role!=='guest'||!S.loggedIn||!h||!data.detail?.trim()||!data.evidence?.trim()||!Number.isFinite(amount)||amount<0||!['CRC','USD'].includes(data.currency))throw Error('Revisá los datos del reporte y las pruebas.');
  const c={id:'R-'+String(claims.next++).padStart(3,'0'),house:h.id,houseTitle:h.t,owner:h.owner,client:'Andrea Castro',reason:data.reason||'Otro problema',detail:data.detail.trim(),evidence:data.evidence.trim(),amount,currency:data.currency,status:'review',refund:'none',finding:'pending',measure:'none',history:[]};
  claimNote(c,'Reporte recibido. No implica culpabilidad.');claims.items.push(c);claims.selected=c.id;return c;
}
function claimAct(c,action,note=''){
  if(!claimAllowed(c))return false;
  note=note.trim();
  if(action==='request_response'&&S.role==='admin'&&note){c.status='owner';}
  else if(action==='accept'&&S.role==='owner'&&c.amount>0&&c.refund==='none'&&note){c.refund='accepted';c.status='owner';}
  else if(action==='respond'&&S.role==='owner'&&note){c.status='review';}
  else if(action==='paid'&&S.role==='owner'&&['accepted','disputed'].includes(c.refund)&&note){c.refund='pending_confirmation';}
  else if(action==='confirm'&&S.role==='guest'&&['pending_confirmation','disputed'].includes(c.refund)){c.refund='confirmed';c.status='resolved';}
  else if(action==='not_received'&&S.role==='guest'&&c.refund==='pending_confirmation'&&note){c.refund='disputed';c.status='review';}
  else if(action==='unresolved'&&S.role==='admin'&&note){c.status='unresolved';}
  else if(action==='appeal'&&S.role!=='admin'&&c.finding!=='pending'&&note){c.status='review';}
  else return false;
  const labels={request_response:'Solicitud de respuesta',accept:'Acepta devolver directamente',respond:'Respuesta del owner',paid:'Comprobante simulado aportado; no acredita recepción',confirm:'Cliente confirma recepción',not_received:'Cliente no confirma recepción',unresolved:'Caso sin acuerdo',appeal:'Revisión de decisión solicitada'};
  claimNote(c,labels[action]+(note?': '+note:'.'));return true;
}
function claimDecide(c,finding,measure,note){
  if(S.role!=='admin'||!note.trim()||!Object.hasOwn(CLAIM_FINDING,finding)||!Object.hasOwn(CLAIM_MEASURE,measure))return false;
  if(finding!=='substantiated'&&['warning','suspension'].includes(measure))return false;
  if(finding==='unsubstantiated'&&measure!=='none')return false;
  c.finding=finding;c.measure=measure;
  claimNote(c,'Decisión simulada: '+CLAIM_FINDING[finding]+' · '+CLAIM_MEASURE[measure]+'. Motivo: '+note.trim());return true;
}
const claimButton=(action,label)=>`<button class="btn btn-ghost" data-claim-action="${action}">${label}</button>`;
function claimsScreen(){
  if(S.role==='guest'&&!S.loggedIn)return header('Reclamaciones','home')+'<p>Ingresá para presentar o consultar un reporte.</p><button class="btn btn-primary" data-go="login">Ingresar</button>';
  if(!['guest','owner','admin'].includes(S.role))return header('Reclamaciones','home');
  const visible=claims.items.filter(claimAllowed),c=visible.find(x=>x.id===claims.selected);
  const intro=header('Reclamaciones',S.role==='guest'?'profile':S.role==='owner'?'o-profile':'a-queue')+`<div class="note"><div><b>Ayuda para gestionar reclamaciones</b><p>Cuota sin recargos por denuncias. Cada reporte se revisa; no demuestra culpabilidad.</p><p>El owner devuelve directamente al cliente. bnbtico no recibe ni adelanta dinero y no garantiza reembolsos.</p></div></div><p class="xs muted">Demo ficticia en memoria. No adjuntés datos personales reales. No hay envíos, cobros ni conexión con Veriff; recargar borra los casos. Las medidas se registran como decisiones de ejemplo, sin bloquear cuentas en esta demo.</p>`;
  const list=`<div class="card stack"><b>Casos ${S.role==='admin'?'para revisar':'de tu cuenta'}</b>${visible.map(x=>`<button class="btn btn-ghost" style="text-align:left;white-space:normal" data-claim-open="${x.id}">${x.id} · ${safe(x.houseTitle)} · ${CLAIM_STATUS[x.status]}</button>`).join('')||'<p class="small muted">Todavía no hay reportes.</p>'}</div>`;
  const create=S.role==='guest'?`<details class="card" ${!visible.length?'open':''}><summary><b>Presentar un reporte</b></summary><div class="stack" style="margin-top:12px">
    <div class="field"><label for="claim-house">Casa relacionada</label><select id="claim-house">${HOUSES.map(h=>`<option value="${h.id}" ${S.params.house===h.id?'selected':''}>${safe(h.t)} · ${h.id}</option>`).join('')}</select></div>
    <div class="field"><label for="claim-reason">Motivo</label><select id="claim-reason"><option>No se cumplió lo acordado</option><option>Posible estafa</option><option>Posible suplantación de identidad</option><option>Otro problema</option></select></div>
    <div class="field"><label for="claim-detail">¿Qué ocurrió y cuándo?</label><textarea id="claim-detail" rows="3" maxlength="2000"></textarea></div>
    <div class="field"><label for="claim-evidence">Pruebas aportadas · descripción de ejemplo</label><textarea id="claim-evidence" rows="2" maxlength="2000" placeholder="Describí conversación y comprobante de ejemplo. Sin subir archivos reales."></textarea><span class="hint">No tenemos acceso a tus mensajes de WhatsApp. En producción podrás aportar las pruebas de forma segura.</span></div>
    <div class="row"><div class="field"><label for="claim-amount">Devolución solicitada (0 si no aplica)</label><input id="claim-amount" type="number" min="0" step="0.01" value="0"></div><div class="field"><label for="claim-currency">Moneda</label><select id="claim-currency"><option value="CRC">CRC · Colones</option><option value="USD">USD · Dólares</option></select></div></div>
    <button class="btn btn-primary" data-claim-create>Registrar reporte · demo</button></div></details>`:'';
  if(!c)return intro+create+list;
  const amount=new Intl.NumberFormat('es-CR',{style:'currency',currency:c.currency}).format(c.amount);
  let actions='';
  if(S.role==='owner')actions=claimButton('respond','Responder / proponer solución')+(c.amount>0&&c.refund==='none'?claimButton('accept','Aceptar devolución de '+amount):'')+(['accepted','disputed'].includes(c.refund)?claimButton('paid','Comunicar devolución y comprobante · demo'):'');
  if(S.role==='guest'&&['pending_confirmation','disputed'].includes(c.refund))actions=claimButton('confirm','Confirmo que recibí el importe')+(c.refund==='pending_confirmation'?claimButton('not_received','No recibí el dinero'):'');
  if(S.role!=='admin'&&c.finding!=='pending')actions+=claimButton('appeal','Solicitar revisión de la decisión');
  if(S.role==='admin')actions=claimButton('request_response','Pedir respuesta al owner')+`<div class="field"><label for="claim-finding">Resultado de revisión</label><select id="claim-finding">${Object.entries(CLAIM_FINDING).map(([k,v])=>`<option value="${k}" ${k===c.finding?'selected':''}>${v}</option>`).join('')}</select></div><div class="field"><label for="claim-measure">Medida proporcional · demo</label><select id="claim-measure">${Object.entries(CLAIM_MEASURE).map(([k,v])=>`<option value="${k}" ${k===c.measure?'selected':''}>${v}</option>`).join('')}</select></div><p class="xs muted">Antes de decidir, revisá las pruebas y escuchá a ambas partes. Una restricción provisional requiere indicios creíbles documentados. Advertencias y suspensiones requieren incumplimiento comprobado. No hay recargos ni reverificaciones de pago automáticas.</p>`+claimButton('decide','Guardar decisión simulada')+claimButton('unresolved','Marcar sin acuerdo');
  return intro+list+`<div class="card stack"><div class="row between"><h3>${c.id}</h3><span class="badge badge-sun">${CLAIM_STATUS[c.status]}</span></div><b>${safe(c.houseTitle)}</b><span class="small">${safe(c.client)} · ${safe(c.owner)}</span><b>${safe(c.reason)}</b><p style="white-space:pre-wrap;overflow-wrap:anywhere">${safe(c.detail)}</p><p class="small"><b>Pruebas descritas:</b> ${safe(c.evidence)}</p><p class="small">Importe solicitado: ${amount}</p><span class="badge badge-mute">${CLAIM_REFUND[c.refund]}</span><p class="small">Revisión: ${CLAIM_FINDING[c.finding]}<br>Medida registrada: ${CLAIM_MEASURE[c.measure]}</p><p class="xs muted">Devolver dinero no elimina una medida ni acredita inocencia. Un comprobante del owner no cierra el caso sin confirmación del cliente. Resolver la devolución no sustituye la revisión de conducta.</p></div>
    <div class="card stack"><h3>${S.role==='admin'?'Revisar caso':'Seguimiento'}</h3>${actions?'<div class="field"><label for="claim-note">Respuesta, motivo o referencia ficticia del comprobante</label><textarea id="claim-note" rows="3" maxlength="2000"></textarea></div>'+actions:'<p class="small muted">Esperá la respuesta o revisión. Podés consultar el historial.</p>'}</div>
    <div class="card stack"><h3>Historial conservado</h3>${c.history.map(e=>`<div class="small" style="overflow-wrap:anywhere"><b>${e.actor==='admin'?'bnbtico':e.actor==='owner'?'Owner':'Cliente'} · ${new Date(e.at).toLocaleString('es-CR',{timeZone:'America/Costa_Rica'})}</b><p>${safe(e.text)}</p></div>`).join('')}</div><p class="xs muted">Si no hay acuerdo, podés acudir a los canales oficiales de denuncia. bnbtico no entrega cédulas ni selfies a la otra parte. Verificar identidad no demuestra quién cometió una estafa.</p>`+create;
}
SCREENS.claims=claimsScreen;
for(const screen of ['profile','o-profile','a-queue']){
  const previous=SCREENS[screen];
  SCREENS[screen]=()=>previous()+((screen!=='profile'||S.loggedIn)?'<button class="btn btn-ghost" data-go="claims">Reclamaciones y ayuda</button>':'');
}
NAV.admin.push(['claims','Reclamaciones',I.shield]);
document.addEventListener('click',event=>{
  const el=event.target.closest('[data-claim-new],[data-claim-open],[data-claim-create],[data-claim-action]');
  if(!el)return;event.stopImmediatePropagation();const d=el.dataset;
  if(d.claimNew){claims.selected=null;go('claims',{house:d.claimNew});return;}
  if(d.claimOpen){const c=claims.items.find(x=>x.id===d.claimOpen);if(c&&claimAllowed(c)){claims.selected=c.id;render();}return;}
  const value=id=>document.getElementById(id)?.value||'';
  if(d.claimCreate!==undefined){try{claimCreate({house:value('claim-house'),reason:value('claim-reason'),detail:value('claim-detail'),evidence:value('claim-evidence'),amount:value('claim-amount'),currency:value('claim-currency')});render();toast('Reporte registrado en la demo. Sin recargos.');}catch(e){toast(e.message);}return;}
  const c=claims.items.find(x=>x.id===claims.selected);if(!c)return;
  const ok=d.claimAction==='decide'?claimDecide(c,value('claim-finding'),value('claim-measure'),value('claim-note')):claimAct(c,d.claimAction,value('claim-note'));
  if(ok){render();toast('Actualizado en la demo. No se ha cobrado ni transferido dinero.');}else toast('Completá el motivo y revisá que la acción corresponda al estado del caso.');
},true);
render();
