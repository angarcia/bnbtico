/* Chat privado de demostración. Sin API, teléfonos reales ni envíos externos.
   Nombre de archivo conservado para no romper las extensiones del prototipo. */
const CONTACT_TTL_DAYS=7, DAY_MS=86400000;
const relay={threads:[],selected:null,next:1042,clockOffset:0,draft:null,preview:null,texts:{}};
const relayNow=()=>Date.now()+relay.clockOffset;
const relayExpired=t=>relayNow()>=t.expiresAt;
const relayDate=ms=>new Intl.DateTimeFormat('es-CR',{dateStyle:'medium',timeStyle:'short',timeZone:'America/Costa_Rica'}).format(ms);
const relayActive=(house,client)=>relay.threads.find(t=>t.house===house&&t.client===client&&!relayExpired(t));
const relayCurrent=()=>relay.threads.find(t=>t.id===relay.selected);
const safe=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const relayHouse=t=>HOUSES.find(h=>h.id===t.house);
function relayActor(t){
  if(!t)return null;
  // Solo para probar ambos lados localmente, nunca autorización real.
  if(S.screen==='chat'&&relay.preview?.thread===t.id&&relay.selected===t.id)return relay.preview.actor;
  if(S.role==='guest'&&S.loggedIn&&t.client==='Andrea Castro')return 'guest';
  if(S.role==='owner'&&MY.some(h=>h.id===t.house))return 'owner';
  return null;
}
function relayCreate(house,client='Andrea Castro',existingLead=null){
  let t=relayActive(house,client);
  if(!t){
    const createdAt=relayNow();
    t={id:'B-'+relay.next++,house,client,createdAt,expiresAt:createdAt+CONTACT_TTL_DAYS*DAY_MS,messages:[],wa:{state:'private',by:null},consents:[]};
    relay.threads.push(t);
    const lead=existingLead||{n:client,h:house,when:'ahora',msg:'Consulta en bnbtico',score:null,count:0,rated:0};
    lead.threadId=t.id;
    if(existingLead)t.messages.push({actor:'guest',text:lead.msg,at:createdAt});
    else S.leads.unshift(lead);
  }
  relay.selected=t.id;return t;
}
S.leads.slice().forEach(l=>relayCreate(l.h,l.n,l));
S.requests.forEach(r=>r.offers.forEach(o=>{
  const h=HOUSES.find(h=>h.id===o.house);if(!h?.ownerV)return;
  const t=relayCreate(h.id,r.client);o.threadId=t.id;
  t.messages.push({actor:'owner',text:`Te propongo «${h.t}». Precio orientativo: ${o.price}. Confirmemos los detalles por acá.`,at:relayNow()});
}));
relay.selected=null;
const relayLeadExpired=l=>{const t=relay.threads.find(t=>t.id===l.threadId);return t&&relayExpired(t);};
function relayLeadExpiry(l){
  const t=relay.threads.find(t=>t.id===l.threadId);
  return t?(relayExpired(t)?'Solicitud expirada · expiró ':'Solicitud activa · vence ')+relayDate(t.expiresAt)+' (Costa Rica)':'';
}
function relayOpenHouse(house){
  relay.preview=null;
  if(S.role!=='guest')return false;
  if(!S.loggedIn){go('login',{id:house,after:'contact'});return false;}
  const h=HOUSES.find(h=>h.id===house&&h.ownerV);
  if(!h){toast('Esta casa aún no está disponible para contactar.');return false;}
  const t=relayActive(house,'Andrea Castro');
  relay.selected=t?.id||null;relay.draft=t?null:{house,client:'Andrea Castro'};
  go('chat');return true;
}
function relayOpenThread(t){
  relay.preview=null;
  if(!relayActor(t))return false;
  relay.selected=t.id;relay.draft=null;go('chat');return true;
}
function relayOpenOffer(house,threadId){
  if(S.role==='guest'&&!S.loggedIn){go('login',{id:house,after:'offer',thread:threadId});return false;}
  const t=relay.threads.find(t=>t.id===threadId&&t.house===house);
  return t?relayOpenThread(t):relayOpenHouse(house);
}
const relayTextKey=()=>relayCurrent()?.id||('draft:'+relay.draft?.house+':'+relay.draft?.client);
function relaySend(text){
  text=String(text).trim();
  if(!text||text.length>2000)return false;
  let t=relayCurrent();const pending=relay.draft,subject=t||pending;
  const actor=relayActor(subject);
  if(!actor||!relayHouse(subject)?.ownerV)return false;
  const key=relayTextKey();
  if(!t)t=relayCreate(pending.house,pending.client);
  t.messages.push({actor,text,at:relayNow()});
  if(pending?.request!==undefined){
    const r=S.requests[pending.request];r.replied=true;
    const offer=r.offers.find(o=>o.house===t.house);
    if(offer)offer.threadId=t.id;
    else r.offers.push({house:t.house,owner:relayHouse(t).owner,price:'precio por confirmar',threadId:t.id});
  }
  relay.texts[key]='';relay.draft=null;return true;
}
function relayConsent(t,action){
  const actor=relayActor(t);if(!actor||!t.messages.length)return false;
  if(action==='propose'&&t.wa.state==='private')t.wa={state:'pending',by:actor};
  else if(action==='accept'&&t.wa.state==='pending'&&t.wa.by!==actor)t.wa={state:'shared',by:t.wa.by};
  else if(action==='decline'&&t.wa.state==='pending'&&t.wa.by!==actor)t.wa={state:'private',by:null};
  else if(action==='cancel'&&t.wa.state==='pending'&&t.wa.by===actor)t.wa={state:'private',by:null};
  else return false;
  t.consents.push({actor,action,at:relayNow()});return true;
}
const relayCanWhatsApp=t=>!!t&&!!relayActor(t)&&t.wa.state==='shared';
function contactHistory(){
  if(S.role==='guest'&&!S.loggedIn)return login();
  const list=relay.threads.filter(t=>relayActor(t)).slice().reverse();
  return header('Mensajes',S.role==='owner'?'o-leads':'profile')+'<p class="small muted">Conversá acá sin mostrar tu teléfono. WhatsApp es opcional y solo se habilita si ambos aceptan.</p>'+
    (list.length?list.map(t=>`<button class="card chat-preview" data-relay-select="${t.id}"><span class="avatar">${ini(S.role==='owner'?t.client:relayHouse(t).owner)}</span><span><b>${safe(S.role==='owner'?t.client:relayHouse(t).owner)}</b><span class="small muted">${safe(relayHouse(t).t)}</span><span class="small chat-excerpt">${safe(t.messages.at(-1)?.text||'Sin mensajes')}</span><span class="xs muted">${relayExpired(t)?'Solicitud expirada · podés seguir hablando':'Solicitud activa'} · ${t.id}</span></span><span aria-hidden="true">→</span></button>`).join(''):'<div class="card"><h3>Todavía no tenés mensajes</h3><p class="small muted">Buscá una casa y tocá «Contactar» para empezar.</p><button class="btn btn-primary" data-go="home">Explorar casas</button></div>');
}
function privateChat(){
  const t=relayCurrent(),subject=t||relay.draft,actor=relayActor(subject);
  if(!actor)return '<div class="card">Ingresá como participante para ver esta conversación.</div>';
  const h=relayHouse(subject),other=actor==='guest'?h.owner:subject.client,wa=t?.wa.state||'private';
  let action='';
  if(t&&wa==='private')action='<button class="btn btn-ghost btn-sm" data-chat-wa="propose">Pasar a WhatsApp</button>';
  if(t&&wa==='pending')action=t.wa.by===actor?'<div class="note small">Esperando su aceptación. Podés seguir hablando acá. <button class="btn-link" data-chat-cancel>Cancelar invitación</button></div>':'<div class="note stack"><b>¿Seguimos por WhatsApp?</b><span class="small">Es opcional. Si aceptás, podrán ver sus números.</span><div class="row chat-actions"><button class="btn btn-wa btn-sm" data-chat-wa="accept">Revisar y aceptar</button><button class="btn btn-ghost btn-sm" data-chat-decline>Seguir por acá</button></div></div>';
  if(t&&wa==='shared')action='<div class="row chat-actions"><span class="small muted">Ambos aceptaron compartir contacto.</span><button class="btn btn-wa btn-sm" data-chat-open-wa>Abrir WhatsApp</button></div>';
  return `<section class="private-chat">${header(safe(other),'contacts')}<button class="btn-link chat-house" data-open="${h.id}">${safe(h.t)} · ${h.id}</button>
    <p class="small muted">Chat privado en bnbtico · no mostramos tu teléfono.</p>
    ${relay.preview?`<div class="note small">Vista de prueba: ${actor==='owner'?'owner':'cliente'}. Estás simulando a ${safe(actor==='owner'?h.owner:subject.client)}.</div>`:''}
    ${action}
    <div class="chat-messages" role="log" aria-label="Mensajes de la conversación" aria-live="polite">${t?.messages.length?t.messages.map(m=>`<div class="chat-message ${m.actor===actor?'mine':''}"><span class="xs muted">${m.actor===actor?'Vos':safe(other)}</span><p>${safe(m.text)}</p><time class="xs muted">${relayDate(m.at)}</time></div>`).join(''):`<div class="chat-empty"><span class="avatar">${ini(other)}</span><h3>Preguntale a ${safe(other.split(' ')[0])}</h3><p class="small muted">Podés consultar fechas, precio o detalles de la casa.</p></div>`}</div>
    <form class="chat-composer" id="chat-form"><label for="chat-text" class="small">Tu mensaje</label><textarea id="chat-text" rows="2" maxlength="2000" placeholder="Hola, ¿está disponible para mis fechas?" required>${safe(relay.texts[relayTextKey()]||'')}</textarea><button class="btn btn-primary" type="submit">Enviar mensaje</button></form>
    <div class="xs muted">${t?`Solicitud ${t.id} · ${relayExpired(t)?'expirada':'vence '+relayDate(t.expiresAt)}. El plazo de 7 días limita nuevas solicitudes, no esta conversación.`:'Tu primer mensaje crea la solicitud. Si volvés a contactar esta casa durante 7 días, abrimos este mismo chat.'}</div>
    <details class="chat-demo"><summary>Probar ambos lados · demo</summary><p class="xs muted">Todo es ficticio, se borra al recargar y no se envía. No ingresés datos reales. La identidad se da por verificada para probar el flujo; no hay verificación ni seguridad real implementadas. El texto del chat no se filtra.</p>${t?`<button class="btn btn-ghost btn-sm" data-chat-preview="${actor==='guest'?'owner':'guest'}">Simular respuesta del ${actor==='guest'?'owner':'cliente'}</button>`:''}</details></section>`;
}
SCREENS.chat=privateChat;SCREENS.contacts=contactHistory;
NAV.guest.splice(2,0,['contacts','Mensajes',I.chat]);
const originalCurrent=current;
current=()=>S.screen==='chat'||S.screen==='contacts'?(S.role==='owner'?'o-leads':'contacts'):originalCurrent();
const originalSetRole=setRole;
setRole=r=>{relay.preview=null;originalSetRole(r);};
const originalProfile=profile;
SCREENS.profile=()=>originalProfile()+(S.loggedIn?'<button class="btn btn-ghost" data-go="contacts">Mis mensajes</button>':'');
const originalLeads=oLeads;
SCREENS['o-leads']=()=>originalLeads()+'<button class="btn btn-ghost" data-go="contacts">Ver todos los mensajes</button><details class="card"><summary>Probar caducidad · demo</summary><p class="small">«No me interesa» no reinicia los 7 días ni bloquea futuras solicitudes. El chat sigue disponible. Recargar restablece la demo.</p><button class="btn btn-ghost" data-relay-week>Avanzar 7 días en la demo</button></details>';
const originalSheet=sheet;
sheet=function(){
  if(S.sheet?.type==='chat-wa'){
    const t=relayCurrent(),action=S.sheet.action;if(!relayActor(t))return '';
    return `<div class="sheet" data-close><div class="sheet-body stack" data-stop><div class="row between"><h3>¿Compartir contacto?</h3><button class="chip" data-close-btn>Cancelar</button></div><p>Al pasar a WhatsApp, la otra persona puede ver y guardar tu número. Recomendamos usar uno de negocio.</p><p class="small muted">${action==='propose'?'Solo se habilita cuando la otra persona también acepta.':'La otra persona ya lo propuso. Si aceptás, ambos podrán abrir WhatsApp.'} bnbtico no puede leer, filtrar ni borrar lo que compartan allí. No puede retirar un número que ya hayan visto.</p><button class="btn btn-wa" data-chat-confirm="${action}">${action==='propose'?'Aceptar y proponer':'Aceptar y habilitar WhatsApp'}</button><span class="xs muted">Demo: no compartimos números ni abrimos WhatsApp.</span></div></div>`;
  }
  if(S.sheet?.type==='reply'){
    const r=S.requests[S.sheet.i],options=matches(r).filter(h=>h.ownerV&&MY.some(m=>m.id===h.id));
    return `<div class="sheet" data-close><div class="sheet-body stack" data-stop><div class="row between"><h3>Responder a ${safe(r.client)}</h3><button class="chip" data-close-btn>Cerrar</button></div><p class="small muted">La propuesta llega al chat privado, sin compartir teléfonos.</p>${options.length?`<label for="relay-house">Casa que ofrecés</label><select id="relay-house">${options.map(h=>`<option value="${h.id}">${safe(h.t)}</option>`).join('')}</select><button class="btn btn-primary" data-chat-reply="${S.sheet.i}">Escribir propuesta</button>`:'<p>No tenés una casa verificada que cumpla esta búsqueda.</p>'}</div></div>`;
  }
  return originalSheet();
};
document.addEventListener('input',e=>{if(e.target.id==='chat-text')relay.texts[relayTextKey()]=e.target.value;});
document.addEventListener('submit',e=>{
  if(e.target.id!=='chat-form')return;e.preventDefault();
  if(!relaySend(document.getElementById('chat-text').value)){toast('Escribí un mensaje de 1 a 2000 caracteres.');return;}
  render();document.getElementById('chat-text')?.focus();
  const log=document.querySelector('.chat-messages');if(log)log.scrollTop=log.scrollHeight;
});
document.addEventListener('click',event=>{
  const el=event.target.closest('[data-chat-wa],[data-chat-confirm],[data-chat-cancel],[data-chat-decline],[data-chat-open-wa],[data-chat-preview],[data-chat-reply],[data-relay-lead],[data-relay-offer],[data-relay-select],[data-relay-dismiss],[data-relay-restore],[data-relay-week]');
  if(!el)return;event.stopImmediatePropagation();const d=el.dataset,t=relayCurrent();
  if(d.relayWeek!==undefined){relay.clockOffset+=CONTACT_TTL_DAYS*DAY_MS;render();return;}
  if(d.relayDismiss!==undefined||d.relayRestore!==undefined){const l=S.leads[Number(d.relayDismiss??d.relayRestore)];if(S.role==='owner'&&l&&!relayLeadExpired(l)){l.dismissed=d.relayDismiss!==undefined;render();}return;}
  if(d.chatPreview){if(t&&relayActor(t)&&['guest','owner'].includes(d.chatPreview)){relay.preview={thread:t.id,actor:d.chatPreview};render();}return;}
  if(d.chatWa){if(t&&relayActor(t)){S.sheet={type:'chat-wa',action:d.chatWa};render();}return;}
  if(d.chatConfirm){if(relayConsent(t,d.chatConfirm)){S.sheet=null;render();}return;}
  if(d.chatCancel!==undefined||d.chatDecline!==undefined){relayConsent(t,d.chatCancel!==undefined?'cancel':'decline');render();return;}
  if(d.chatOpenWa!==undefined){if(relayCanWhatsApp(t))toast('Demo: abriríamos WhatsApp. No se compartió ningún número ni se envió un mensaje.');return;}
  if(d.chatReply!==undefined){
    const i=Number(d.chatReply),r=S.requests[i],house=document.getElementById('relay-house').value;
    if(S.role!=='owner'||!r||!matches(r).some(h=>h.id===house&&h.ownerV&&MY.some(m=>m.id===house)))return;
    relay.preview=null;relay.selected=relayActive(house,r.client)?.id||null;
    relay.draft={house,client:r.client,request:i};go('chat');return;
  }
  if(d.relayOffer){relayOpenOffer(d.relayOffer,d.relayThread);return;}
  const lead=d.relayLead!==undefined?S.leads[Number(d.relayLead)]:null;
  const selected=relay.threads.find(t=>t.id===(lead?lead.threadId:d.relaySelect));
  if(selected)relayOpenThread(selected);
},true);
render();
