# CasaTica

Catálogo de casas en alquiler en Costa Rica (vacacional y largo plazo). Los owners publican; los clientes los contactan **en un chat privado; WhatsApp es opcional si ambos aceptan**. La app no gestiona reservas ni pagos entre partes; cobra una suscripción por casa activa al owner, sin comisiones.

## Documentación (leer antes de tocar código)
- `docs/vision.md` — problema, usuarios, principios, qué es éxito
- `docs/business-model.md` — quién paga, precio, cómo se cobra, riesgos
- `docs/design.md` — pantallas, flujos, sistema de diseño, copy
- `docs/architecture.md` — stack, modelo de datos, reglas de negocio en backend
- `docs/roadmap.md` — v1 como checklist, v2, quizás nunca, pendientes
- `docs/pitch.md` — pitch a owners, objeciones y respuestas
- `docs/decisiones.md` — por qué se decidió cada cosa
- `docs/resumen-sesion-2026-10-02.md` — decisiones finales, alternativas descartadas y estado real
- `docs/identidad-y-seguridad.md` — identidad de ambos roles con Veriff, titularidad opcional y seguridad propuesta
- `docs/guia-verificacion-finca.md` — guía para owners: segunda verificación opcional por finca
- `docs/privacidad-verificaciones.md` — acceso a datos de Veriff, requisitos de privacidad y revisión jurídica pendiente
- `docs/reclamaciones.md` — reportes, devolución directa, medidas sin recargos y límites de la demo

Referencias: prototipo navegable en `design/prototype/casatica-prototipo.html` (abrir en navegador; no es código de producción; también publicado como artifact "CasaTica Prototipo" en claude.ai), tokens en `design/tokens/tokens.json`, esquema en `supabase/migrations/0001_init.sql`, seed en `supabase/seed/seed.sql`.

## Estado actual
Fase de definición e iteración (2026-10-02): no hay código de aplicación todavía. `apps/` y `packages/` contienen solo READMEs. El siguiente paso es el scaffold (ver `docs/roadmap.md › v1 › Base`).

## Contexto de trabajo actualizado · 2026-10-02
- Repositorio real: `/Users/anagarciasaiz/Documents/GitHub/CasaTica`, remoto esperado `https://github.com/angarcia/CasaTica`. No confundir con el repo vacío creado inicialmente bajo `Documents/Codex/2026-10-02/me-x20/CasaTica`.
- `AGENTS.md` es un enlace simbólico a este archivo (`CLAUDE.md`); mantener una única fuente de instrucciones y preservar el enlace.
- Prioridad actual de la usuaria: iterar sobre el prototipo existente antes de arrancar el scaffold. No implementar el roadmap ni renombrar la marca automáticamente.
- Enfoque expresado por la usuaria: que los propietarios hagan comunidad local. Aún falta definir las interacciones entre propietarios; recomendaciones de huéspedes, consejos y proveedores son ideas, no requisitos aprobados. El prototipo actual conecta propietarios con clientes, pero no implementa esa comunidad entre propietarios.
- Dirección de marca: bnbtico, rana sonriente sobre hoja en rojo coral. Se exploraron Nidaluma, Ticosticos y Localtico; son alternativas históricas. Dominio/marca legal pendientes de confirmar; no renombrar archivos automáticamente.
- La usuaria indicó que `casalo.com` no está disponible y que comprobaría dominios en GoDaddy. No presentar consultas antiguas ni propuestas creativas como disponibilidad actual confirmada. El estado de `ticosticos.com` no está confirmado de forma inequívoca.

### Ejecutar y revisar el prototipo
- Archivo único: `design/prototype/casatica-prototipo.html`; HTML/CSS/JS con datos de ejemplo, sin instalación ni build. No existe aún un `npm run dev` de la aplicación.
- Vista local HTTP, solo loopback y sirviendo únicamente la carpeta del prototipo:
  `python3 -m http.server 8765 --bind 127.0.0.1 --directory design/prototype`
- Abrir `http://127.0.0.1:8765/casatica-prototipo.html`. Si el puerto está ocupado, comprobar qué sirve antes de reutilizarlo; no terminar procesos ajenos.
- Selectores superiores: Cliente / Owner / Admin / Landing y Móvil / Web. Inicio por defecto: Cliente, Móvil. Estado solo en memoria; recargar restablece la demo.
- Puntos de entrada en el HTML: `HOUSES` (datos), `S` (estado), `home`, `detail`, `request`, `oDash`, `oRequests`, `landing`, `SCREENS`, `render` y el manejador de clics por atributos `data-*`.
- Filtros, favoritos y navegación son interactivos. Fotos son degradados; mapa, subida de archivos, autenticación y pagos son simulaciones. Los botones de contacto muestran mensajes de demo: no asumir que abren WhatsApp realmente. Ver `docs/design.md` para el alcance detallado.
- Estética actual (2026-10-05): bnbtico, logo original rana sobre hoja en `design/prototype/assets/bnbtico-original.png` (panel inferior encuadrado con CSS), coral `#FF385C`, acciones `#D92349`, papel cálido `#F7F5EF`. Verde para WhatsApp/estados positivos y mostaza para avisos/estrellas; Bricolage Grotesque y Nunito Sans (fallback local). No regenerar el logo elegido: el original ya está guardado en el repo.
- Para cada iteración: revisar el estado de Git, leer los documentos relevantes antes de modificar código, preservar cambios existentes y verificar los flujos afectados en móvil y web. No dar por verificado el renderizado por leer solo el HTML.

## Principios que no se negocian
1. Última arquitectura provisional: cliente en chat de bnbtico y owner en su número/aplicación habituales de WhatsApp Business, con un número intermediario por cliente. Condicionada a proveedor, límites, coste y reglas de entrega; no contratar ni comprar números sin autorización. WhatsApp directo entre las partes sigue siendo opcional con aceptación bilateral. La demo actual en `design/prototype/relay.js` todavía simula ambas partes dentro de la app, sin puente ni envíos reales. No se ofrece contacto propietario → propietario.
2. No prometer números ocultos en WhatsApp. Recomendar número de negocio y advertir antes de salir. En Pedir casa se exige consentimiento explícito para que un máximo de 10 owners verificados compatibles respondan en el chat privado, sin recibir automáticamente el teléfono. Especificación vigente: `docs/chat-privado.md`.
3. Precios siempre orientativos; nunca "total a pagar" ni pagos entre partes.
4. Los owners valoran a los clientes; no hay reseñas de casas.
5. Identidad obligatoria para clientes y propietarios (documento + rostro + liveness): antes de contactar/enviar solicitudes o publicar/responder. Registro y borradores sin esa barrera inicial. Veriff elegido como dirección de producto, no contratado/integrado; Essential candidato de plan. Segunda comprobación opcional de titularidad registral por casa/finca, sin verificar autorización de alquiler. No solicitarla no bloquea publicación. Ver `docs/identidad-y-seguridad.md` y `docs/privacidad-verificaciones.md`; revisión jurídica pendiente antes de recoger datos reales.
6. UI en español de Costa Rica con voseo. Colones por defecto.
7. Una solicitud de contacto activa por cliente y casa durante 7 días desde su envío (configurable). Reintentar abre la existente sin otro aviso. «No me interesa» no reinicia el plazo ni bloquea futuras solicitudes. Caducidad no elimina historial ni cierra conversaciones. Demo y especificación: `relay.js` y `docs/chat-privado.md`. El límite no restringe mensajes fuera de bnbtico.

## Convenciones de código
- Monorepo pnpm + Turborepo: `apps/web` (Next.js), `apps/mobile` (Expo), `packages/ui|api-client|config`, `supabase/`.
- TypeScript estricto. Entidades en inglés (`Listing`, `Lead`, `Request`); copy en español.
- Dinero como entero + `currency` (`CRC` | `USD`); formato `₡95.000` / `$120`; cifras tabulares.
- Amenidades como enum: `pool, pets, ev_charger, ac, wifi, beachfront, bbq, parking, furnished, garage, accessible, no_deposit`.
- IDs públicos de casa `CT-####`.
- Tests: Vitest (matching, dinero, extracción de requisitos); Playwright (buscar → ficha → contactar).
- Commits en español, imperativo. Si cambias una decisión, anótala en `docs/decisiones.md`.

## Orden sugerido
Iteración de titularidad 2026-10-05: `design/prototype/property.js` añade **Owner → Mis casas → Verificar propiedad**, guía de 3 pasos o atajo al código, aviso/consentimiento y revisión simulada por casa. Solo código ficticio; no datos reales, aprobación ni conexión con admin. Progreso en memoria, recargar lo borra. Prueba: `node tests/prototype/property-verification.cjs`. Los dos sellos y sus textos aprobados están en `docs/identidad-y-seguridad.md`; su despliegue público sigue pendiente.

Iteración 2026-10-05: claims.js añade reclamaciones por rol y confirmación de recepción de devolución. Medidas solo registradas como decisiones simuladas; no bloquean cuentas en la demo. No se sube la cuota por denuncias. No hay transferencias reales ni garantía de reembolso.

Actualización de producto: marca `bnbtico`, logo de rana sobre hoja monocromo rojo coral (no la rana saltando), aplicado al prototipo el 2026-10-05. No cambiar assets como parte de una tarea de mensajería. Nombre del repo, archivo HTML e IDs CT se conservan.

Última iteración 2026-10-07: chat privado por defecto y WhatsApp opcional con doble consentimiento. Cliente → Mensajes; Owner → Contactos → Responder. Control «Probar ambos lados · demo» dentro del chat para simular al otro participante, nunca autorización real. Se mantienen los 7 días, el historial y «No me interesa». Sin intermediario ni ventanas de 24 h. Demo sin API, persistencia, filtro de texto o números utilizables; recargar restablece todo. Especificación vigente: `docs/chat-privado.md`. Copia anterior en `backups/bnbtico-antes-chat-privado-2026-10-07.tar.gz`.

Decisión posterior de la misma sesión, aún no implementada: puente de WhatsApp por cliente para que el owner responda desde su Business habitual. `docs/chat-privado.md` distingue arquitectura provisional y demo real. Antes de implementarlo, resolver varias casas/solicitudes por la misma pareja de participantes, ventanas de envío, ciclo de vida de alias y aprobación/coste del proveedor. Esta decisión sustituye el descarte de intermediarios, no modifica la demo por sí sola.

La política nueva de identidad aún no está reflejada en todas las pantallas ni migraciones. Las passkeys y demás medidas de protección de cuentas son propuestas pendientes de aprobación/diseño.

Scaffold + tokens + Supabase local → catálogo web + contacto + identidad y auth → panel owner + admin → solicitudes y matching → suscripción → móvil.
